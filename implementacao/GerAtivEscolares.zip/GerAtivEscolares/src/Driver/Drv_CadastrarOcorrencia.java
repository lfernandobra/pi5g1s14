package Driver;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import Controle.CtlOcorrencia;
import Entidade.Aluno;
import Entidade.Ocorrencia;
import Entidade.Turma;


public class Drv_CadastrarOcorrencia {
	private static String RA;
	private static String descricao;
	private static Date dataOcorrencia;
	private static Aluno alunoaux;
	private static CtlOcorrencia Controle;
	
	public static Aluno SolicitaAluno(String RA){
		//2. ListaAluno()
		System.out.println(Controle.ListaAluno());
		//3. listaAluno[] = obtemAluno(RA)
		return Controle.ObtemAluno(RA);
	}
	public static boolean CadastrarOcorrencia(Aluno alu,Date data,String desc){
		//4. ListaOcorrencia
		System.out.println(Controle.ListaOcorrencia());
		//6. ConfirmaOcorrencia(ocorrencia)
		return Controle.ConfirmaOcorrencia(alu,data,desc);
	}
	
			
	public static void main(String[] args) throws ParseException{
		// TODO Auto-generated method stub
		
		//BDOcorrencias Stub
		ArrayList<Ocorrencia> Stb_BDOcorrencia = new ArrayList<Ocorrencia>();
		ArrayList<Aluno> Stb_BDaluno = new ArrayList<Aluno>();		
			
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
		// instanciando turma
		
		Turma Stb_turmaA = new Turma ("A","2014");
		
		// instanciando alunos com seus respectivos parametros
		
		Date dataNascimento = formatador.parse("24/04/1998");
		
		Aluno Stb_alunoA = new Aluno("1","Julia Yukari",Stb_turmaA,"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",dataNascimento);
		Stb_BDaluno.add(Stb_alunoA);
				
		
		
		//Instanciando a classe controle Ocorrencia
		Controle = new CtlOcorrencia(Stb_BDOcorrencia,Stb_BDaluno);
		RA = "1";
		
		alunoaux = new Aluno();
		
		
		//1. SolicitaAluno()
		if(Controle.VerificaAluno(RA)){
			alunoaux=SolicitaAluno(RA);
			//5. CadastrarOcorrencia
			descricao="Desrespeitou o professor";
			dataOcorrencia = formatador.parse("24/04/2014");
			
			System.out.println(CadastrarOcorrencia(alunoaux,dataOcorrencia,descricao)?"Ocorr�ncia cadastrada":"Ocorr�ncia n�o cadastrada");
			
			//7. SalvaOcorrencia
			System.out.println(Controle.ListaOcorrencia());
		}else {
			System.out.println("Aluno n�o cadastrado , n�o possivel o cadastro da ocorrencia");
		}
		//
		
		
		

	}

}
