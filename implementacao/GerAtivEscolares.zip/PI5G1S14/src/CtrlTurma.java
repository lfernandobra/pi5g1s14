import java.util.ArrayList;


public class CtrlTurma {
	
	private ArrayList<Turma> Stb_turmas = new ArrayList<Turma>();
	
	// construtores
	public CtrlTurma(){
		super();
	}
	
	//salvar turma
	
	public void inserirTurma(Turma t){
		Stb_turmas.add(t);
	}
	
	//obtem turma da lista
	
	public Turma obtemTurma(String nomeTurma){
		Turma turma = new Turma();
		for (int i = 0;i<Stb_turmas.size();i++){
			if(Stb_turmas.get(i).getNomeTurma() == nomeTurma){
				turma = Stb_turmas.get(i);
			}
		}
		return turma;
		
	}
	//Editando uma turma 
	public void editarTurma(String nomeTurma,String nome,String ano){
				
		for(int i=0;i<Stb_turmas.size();i++){
					
			if(Stb_turmas.get(i).getNomeTurma() == nomeTurma){
			//alterando o aluno
			  Stb_turmas.get(i).setNomeTurma(nome);
			  Stb_turmas.get(i).setAnoTurma(ano);
			}
		}
				
	}
		
		
		//Excluindo um aluno da lista de alunos
	public void excluirTurma(String nomeTurma){
		for(int i=0;i<Stb_turmas.size();i++){
					
			if(Stb_turmas.get(i).getNomeTurma() == nomeTurma){
			//excluindo o aluno
			  Stb_turmas.remove(i);
			}
		}
	}
		
		
		//toString
		public String toString(){
			String res = "Lista de turmas\n";
			
			for(int i=0;i<Stb_turmas.size();i++){
				res+=Stb_turmas.get(i).toString();
			}		
			return res;
		}
	
}
