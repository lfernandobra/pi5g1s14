import java.util.ArrayList;
import java.util.Date;

public class CtrlOcorrencia {
	
	private ArrayList<Ocorrencia> Stb_ocorrencias = new ArrayList<Ocorrencia>();
	
	//Construtores
	public CtrlOcorrencia(){
		super();
	}
	
	//metodos
	//Salvar ocorrencia
	public void inserirOcorrencia(Ocorrencia Oc){
		
		Oc.setID_ocorrencia(Stb_ocorrencias.size()+1);
		Stb_ocorrencias.add(Oc);
		
	}
	
	//Obtem ocorrencias por Aluno
	public CtrlOcorrencia obtemOcorrencia(Aluno a){
		
		CtrlOcorrencia OcorAluno = new CtrlOcorrencia();
		
		for(int i=0;i<Stb_ocorrencias.size();i++){
			if(Stb_ocorrencias.get(i).getAluno().getRA()==a.getRA()){
				OcorAluno.Stb_ocorrencias.add(Stb_ocorrencias.get(i));
			}
		}
		
		return OcorAluno;
	}	
	
	//Obtem ocorrencia por Turma
	public CtrlOcorrencia obtemOcorrencia (Turma t){
		
		CtrlOcorrencia OcorTurma = new CtrlOcorrencia();
		for(int i=0;i<Stb_ocorrencias.size();i++){
			if(Stb_ocorrencias.get(i).getAluno().getTurma().getNomeTurma()==t.getNomeTurma()){
				OcorTurma.Stb_ocorrencias.add(Stb_ocorrencias.get(i));
				
			}
		}
		
		return OcorTurma;
		
	}
	
	//Editando uma ocorrencia
	public void editarOcorrencia(int IDOc,Aluno alu,Date data,String desc){
		
		for(int i=0;i<Stb_ocorrencias.size();i++){
			
			if(Stb_ocorrencias.get(i).getID_ocorrencia() == IDOc){
				//alterando o aluno
				Stb_ocorrencias.get(i).setAluno(alu);
				Stb_ocorrencias.get(i).setData_ocorrencia(data);
				Stb_ocorrencias.get(i).setDesc_ocorrencia(desc);
			}
		}
		
	}
	//Excluindo uma ocorrencia da lista de Ocorrencia
	public void excluirOcorrencia(int IDOc){
		for(int i=0;i<Stb_ocorrencias.size();i++){
			
			if(Stb_ocorrencias.get(i).getID_ocorrencia() == IDOc){
				//excluindo o aluno
				Stb_ocorrencias.remove(i);
			}
		}
	}
	
		
	//toString 
	public String toString(){
		String res = "Lista de Ocorrencias";
		
		for(int i=0;i<Stb_ocorrencias.size();i++){
			res+=Stb_ocorrencias.get(i).toString();
		}
		
		return res;
	}
}
