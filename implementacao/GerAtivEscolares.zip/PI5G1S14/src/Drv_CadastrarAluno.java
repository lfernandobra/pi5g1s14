
public class Drv_CadastrarAluno {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1. SelecionaMatricula() n�o implementado 
		
		// 2. InsereDados()
		
		// 3. VerificaDados() n�o implementado
		// 4. SalvarAluno()
		Aluno Stb_alunoA = new Aluno("1","Julia",null,"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",null);
		//instanciado a um objeto da classe controle de alunos
		CtrlAluno CtrlAluno = new CtrlAluno();
		
		CtrlAluno.inserirAluno(Stb_alunoA);
		
		//instanciando objetos da classe Turma
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		
		//BDTurmas Stub
		CtrlTurma Stb_CtrlTurmas = new CtrlTurma();
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		
		// 5. SelecTurma()
				
		// 6. VerificaTurma() n�o implementado
		
		// 7. Inclui Aluno
		
		CtrlAluno.obtemAluno("1").setTurma(Stb_CtrlTurmas.obtemTurma("B"));
		
		System.out.println(CtrlAluno);
		
		
		

	}

}
