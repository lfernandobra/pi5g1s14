import junit.framework.TestCase;


public class JUnitTest extends TestCase {
	
	public Turma tur01 = new Turma("A","2014");
	public Aluno alu01 = new Aluno("1","Luis",tur01);
	public Ocorrencia ocor01 = new Ocorrencia();
	public listaAluno listAlu = new listaAluno();
	public listaOcorrencia listOcor = new listaOcorrencia();
	
	public JUnitTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
		
	}
	
	
	//Testes
	
	//Adicionando Aluno � lista de alunos
	public void testAddAluno(){
		boolean add = true;
		boolean addAluno = false;
		while(!addAluno){
			listAlu.inclusaoAluno(alu01);
			addAluno = true;
		}
		assertEquals(add,addAluno);
	}
	
	//Atribuindo ocorrencia ao aluno
	
	public void testAddOcorAlu() {
		boolean add = true;
		boolean addOcor = false;
		
		while(!addOcor){
			
			ocor01.setID_ocorrencia(0);
			ocor01.setAluno(alu01);
			ocor01.setData_ocorrencia(null);
			ocor01.setDesc_ocorrencia("Desrespeito ao professor");
			addOcor = true;
		}
		assertEquals(add,addOcor);		 
	}
	
	//Adicionando Ocorrencia a lista de Ocorrencias
	
	public void testaddOcorList(){
		boolean add = true;
		boolean addOcorList = false;
		while(!addOcorList){
			listOcor.salvarOcorrencia(ocor01);
			System.out.println(listOcor);
			addOcorList = true;
		}
		assertEquals(add,addOcorList);
	}
	
}
