
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



public class Drv_InserirOcorrencia {

			
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		
		// instanciando alunos com seus respectivos parametros (RA,Nome,Turma)
		Aluno Stb_alunoA = new Aluno("1","Ana",Stb_turmaA);
		Aluno Stb_alunoB = new Aluno("2","Luis Fernando",Stb_turmaB);
		Aluno Stb_alunoC = new Aluno("3","Luiza Helena",Stb_turmaA);
		Aluno Stb_alunoD = new Aluno("4","Waldinei",Stb_turmaB);
		
		// instanciado a lista de alunos
		listaAluno Stb_listaAlunoADS = new listaAluno();
		
		
		// inserindo alunos a lista de alunos
		Stb_listaAlunoADS.inclusaoAluno(Stb_alunoA);
		Stb_listaAlunoADS.inclusaoAluno(Stb_alunoB);
		Stb_listaAlunoADS.inclusaoAluno(Stb_alunoC);
		Stb_listaAlunoADS.inclusaoAluno(Stb_alunoD);
		
		//Formatador para o atributo tipo date
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
		Date dataA1 = formatador.parse("24/04/2014");
		Date dataA2 = formatador.parse("23/03/2014");
	    	
		// instanciando ocorrencias para os respectivos alunos
		Ocorrencia A1 = new Ocorrencia(1,Stb_alunoA,dataA1,"Desrespeito ao Professor em sala de aula");
		Ocorrencia A2 = new Ocorrencia(2,Stb_alunoB,dataA2,"Saiu antes do termino da aula");
		
		// instanciando a lista de Ocorrencias
		listaOcorrencia Stb_listaOcorrenciaADS = new listaOcorrencia();
		
		// adicionando ocorrencias a lista
		Stb_listaOcorrenciaADS.salvarOcorrencia(A1);
		Stb_listaOcorrenciaADS.salvarOcorrencia(A2);
		
		// exibindo a lista de ocorrencias
		System.out.println(Stb_listaOcorrenciaADS);

	}

}
