import java.util.*;
public class Ocorrencia {
	
	private int ID_ocorrencia;
	private Aluno Aluno;	//identificacao aluno
	private Date data_ocorrencia; //data ocorrencia
	private String desc_ocorrencia; //descri��o ocorrencia
	
	//Getters and Setters
	public int getID_ocorrencia() {
		return ID_ocorrencia;
	}
	public void setID_ocorrencia(int iD_ocorrencia) {
		ID_ocorrencia = iD_ocorrencia;
	}
	
	public Aluno getAluno() {
		return Aluno;
	}
	public void setAluno(Aluno A) {
		Aluno = A;
	}
	public Date getData_ocorrencia() {
		return data_ocorrencia;
	}
	public void setData_ocorrencia(Date data_ocorrencia) {
		this.data_ocorrencia = data_ocorrencia;
	}
	public String getDesc_ocorrencia() {
		return desc_ocorrencia;
	}
	public void setDesc_ocorrencia(String desc_ocorrencia) {
		this.desc_ocorrencia = desc_ocorrencia;
	}
	
	//Construtores
	
	//sem parametro
	public Ocorrencia(){
		super();
	}
	//com parametros
	public Ocorrencia(int ID_ocor,
					  Aluno A,
					  Date data_ocor,
					  String desc_ocor){
		this.ID_ocorrencia = ID_ocor;
		this.Aluno = A;
		this.data_ocorrencia = data_ocor;
		this.desc_ocorrencia = desc_ocor;
	
	}
	
	public String toString(){
		return "\nID Ocorr�ncia : "+ID_ocorrencia+
			   "\nAluno : "+Aluno+
			   "\nData : "+data_ocorrencia+
			   "\nDescri��o : "+desc_ocorrencia;
	}

}
