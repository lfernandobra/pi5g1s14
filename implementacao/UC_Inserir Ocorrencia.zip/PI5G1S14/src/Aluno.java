
public class Aluno {
	
	private String RA;
	private String Nome;
	private Turma turma;
	
	
	//Getters and Setters
	
	public String getRA() {
		return RA;
	}
	public void setRA(String rA) {
		RA = rA;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public Turma getTurma() {
		return turma;
	}
	public void setTurma(Turma turma) {
		this.turma = turma;
	}
	
	//Construtores
	
	public Aluno(){
		super();
	}
	
	public Aluno(String RA,String Nome,Turma turma){
		super();
		this.RA = RA;
		this.Nome = Nome;
		this.turma = turma;
	}
	
	//toString
	public String toString(){
		return "\nRA : "+RA+
				"\nNome : "+Nome+
				"\nTurma : "+turma;
	}
	
	
	
}
