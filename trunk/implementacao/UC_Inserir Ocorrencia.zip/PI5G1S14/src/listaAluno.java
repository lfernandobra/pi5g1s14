import java.util.ArrayList;

public class listaAluno {
	
	private ArrayList<Aluno> turma = new ArrayList<Aluno>();
	
	//Construtores
	
	public listaAluno(){
		super();
	}
		
	//metodos
	//salvar aluno a turma
	public void inclusaoAluno(Aluno a){
		turma.add(a);
	}
	
	//obtem aluno da turma
	public Aluno obtemAluno(String RA){
		Aluno aluno = new Aluno();
		for (int i = 0;i>turma.size();i++){
			if(turma.get(i).getRA()== RA){
				aluno = turma.get(i);
			}
		}
		return aluno;
		
	}
	//toString
	public String toString(){
		String res = "Lista de alunos";
		
		for(int i=0;i<turma.size();i++){
			res+=turma.get(i).toString();
		}
		return res;
	}
	
	
	
	
}
