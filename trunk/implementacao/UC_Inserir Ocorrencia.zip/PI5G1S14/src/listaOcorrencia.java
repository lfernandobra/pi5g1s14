import java.util.ArrayList;

public class listaOcorrencia {
	
	private ArrayList<Ocorrencia> ocorrencias = new ArrayList<Ocorrencia>();
	
	//Construtores
	public listaOcorrencia(){
		super();
	}
	
	//metodos
	//Salvar ocorrencia
	public void salvarOcorrencia(Ocorrencia Oc){
		ocorrencias.add(Oc);
	}
	//Obtem ocorrencia por Aluno
	public Ocorrencia obtemOcorrencia(String RA){
		Ocorrencia Ocor = new Ocorrencia();
		for(int i=0;i<ocorrencias.size();i++){
			if(ocorrencias.get(i).getAluno().getRA()==RA){
				Ocor = ocorrencias.get(i);
			}
		}
		
		return Ocor;
	}
	
	//toString 
	public String toString(){
		String res = "Lista de Ocorrencias";
		
		for(int i=0;i<ocorrencias.size();i++){
			res+=ocorrencias.get(i).toString();
		}
		
		return res;
	}
}
