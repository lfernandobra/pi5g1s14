
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



public class TestarInserirOcorrencia {

			
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		//instanciando objetos da classe Turma
		Turma A = new Turma("A","2014");
		Turma B = new Turma("B","2013");
		
		// instanciando alunos com seus respectivos parametros (RA,Nome,Turma)
		Aluno a = new Aluno("1","Ana",A);
		Aluno b = new Aluno("2","Luis Fernando",B);
		Aluno c = new Aluno("3","Luiza Helena",A);
		Aluno d = new Aluno("4","Waldinei",B);
		
		// instanciado a lista de alunos
		listaAluno ADS = new listaAluno();
		
		
		// inserindo alunos a lista de alunos
		ADS.inclusaoAluno(a);
		ADS.inclusaoAluno(b);
		ADS.inclusaoAluno(c);
		ADS.inclusaoAluno(d);
		
		//Formatador para o atributo tipo date
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
		Date dataA1 = formatador.parse("24/04/2014");
		Date dataA2 = formatador.parse("23/03/2014");
	    	
		// instanciando ocorrencias para os respectivos alunos
		Ocorrencia A1 = new Ocorrencia(1,a,dataA1,"Desrespeito ao Professor em sala de aula");
		Ocorrencia A2 = new Ocorrencia(2,b,dataA2,"Saiu antes do termino da aula");
		
		// instanciando a lista de Ocorrencias
		listaOcorrencia ADSOc = new listaOcorrencia();
		
		// adicionando ocorrencias a lista
		ADSOc.salvarOcorrencia(A1);
		ADSOc.salvarOcorrencia(A2);
		
		// exibindo a lista de ocorrencias
		System.out.println(ADSOc);

	}

}
