package edu.gaed.modelo;

public class Aluno extends Usuario{
	
	protected int ID_Aluno;
	protected int ID_Usuario;
	protected int ID_Responsavel;
	protected String Data_Ingresso;
	
	public Aluno() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getID_Aluno() {
		return ID_Aluno;
	}

	public void setID_Aluno(int iD_Aluno) {
		ID_Aluno = iD_Aluno;
	}

	public int getID_Usuario() {
		return ID_Usuario;
	}

	public void setID_Usuario(int iD_Usuario) {
		ID_Usuario = iD_Usuario;
	}

	public int getID_Responsavel() {
		return ID_Responsavel;
	}

	public void setID_Responsavel(int iD_Responsavel) {
		ID_Responsavel = iD_Responsavel;
	}

	public String getData_Ingresso() {
		return Data_Ingresso;
	}

	public void setData_Ingresso(String data_Ingresso) {
		Data_Ingresso = data_Ingresso;
	}
	
}
