package edu.gaed.modelo;

public class Responsavel {
	
	protected int ID_Usuario;
	protected int ID_Responsavel;
	protected String CPF;
	
	public Responsavel() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getID_Usuario() {
		return ID_Usuario;
	}

	public void setID_Usuario(int iD_Usuario) {
		ID_Usuario = iD_Usuario;
	}

	public int getID_Responsavel() {
		return ID_Responsavel;
	}

	public void setID_Responsavel(int iD_Responsavel) {
		ID_Responsavel = iD_Responsavel;
	}

	public String getCPF() {
		return CPF;
	}

	public void setCPF(String cPF) {
		CPF = cPF;
	}
}
