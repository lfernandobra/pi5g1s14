package edu.gaed.modelo;

public class Turma {
	
	protected int ID_Turma;
	protected String Nome_Turma;
	protected String Periodo;
	protected String Serie;
	protected String Ano_Letivo;
	protected String Bimestre;
	
	public Turma() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getID_Turma() {
		return ID_Turma;
	}
	public void setID_Turma(int iD_Turma) {
		ID_Turma = iD_Turma;
	}
	public String getNome_Turma() {
		return Nome_Turma;
	}
	public void setNome_Turma(String nome_Turma) {
		Nome_Turma = nome_Turma;
	}
	public String getPeriodo() {
		return Periodo;
	}
	public void setPeriodo(String periodo) {
		Periodo = periodo;
	}
	public String getSerie() {
		return Serie;
	}
	public void setSerie(String serie) {
		Serie = serie;
	}
	public String getAno_Letivo() {
		return Ano_Letivo;
	}
	public void setAno_Letivo(String ano_Letivo) {
		Ano_Letivo = ano_Letivo;
	}
	public String getBimestre() {
		return Bimestre;
	}
	public void setBimestre(String bimestre) {
		Bimestre = bimestre;
	}
	
	

}
