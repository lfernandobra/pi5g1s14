package Controle;

import Entidade.Turma;
import Stub.BDTurma;

public class CtlTurma {
	
	private BDTurma turmas = new BDTurma();
	
	
	public CtlTurma(BDTurma turmas) {
		super();
		this.turmas = turmas;
	}

	public BDTurma getTurmas() {
		return turmas;
	}

	public void setTurmas(BDTurma turmas) {
		this.turmas = turmas;
	}
	
	//metodos
	//ListaTurmas
	public BDTurma listaTurmas(){
		return turmas;
	}
	//VerificaTurma
	public boolean verificaTurma(String nomeTurma){
		boolean verifica = false;
		for(int i=0;i<turmas.getBDTurma().size();i++){
			if(turmas.getBDTurma().get(i).getNomeTurma().equals(nomeTurma)){
				verifica = true;
			}
		}
		return verifica;
	}
	
	//Cadastrar aluno a lista de alunos
	public boolean cadastrarTurma(Turma a){
			
		if(verificaTurma(a.getNomeTurma())){return false;}
		else
				{	turmas.getBDTurma().add(a);
					return true;
				}
	}
	//Consultar Turma
	public Turma consultarTurma(String nome){
		Turma turma = new Turma();
		for (int i = 0;i<turmas.getBDTurma().size();i++){
			if(turmas.getBDTurma().get(i).getNomeTurma()==nome){
				turma = turmas.getBDTurma().get(i);
			}
		}
		return turma;
	}
	
	public void confirmaDados(Turma turma,String nome,String ano){
		for(int i=0;i<turmas.getBDTurma().size();i++){
			if(turmas.getBDTurma().get(i).getNomeTurma() == turma.getNomeTurma()){
			
				if(nome!=turmas.getBDTurma().get(i).getNomeTurma()&&nome!=null){
					turmas.getBDTurma().get(i).setNomeTurma(nome);
				}
				if(ano!=turmas.getBDTurma().get(i).getAnoTurma()&&ano!=null){
					turmas.getBDTurma().get(i).setAnoTurma(ano);
				}
			}
		}
	}
	
}
