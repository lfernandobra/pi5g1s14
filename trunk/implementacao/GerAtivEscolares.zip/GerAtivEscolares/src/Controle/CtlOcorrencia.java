package Controle;
import java.util.ArrayList;
import java.util.Date;

import Entidade.Aluno;
import Entidade.Ocorrencia;


public class CtlOcorrencia {
	
	private ArrayList<Ocorrencia> ocorrencias;
	private ArrayList<Aluno> alunos;
	
	//Construtores
	
	public CtlOcorrencia(ArrayList<Ocorrencia> ocorrencias, ArrayList<Aluno> alunos) {
		super();
		this.ocorrencias = ocorrencias;
		this.alunos = alunos;
	}
	
	//Getters and setters
	
	public ArrayList<Ocorrencia> getOcorrencias() {
		return ocorrencias;
	}


	public void setOcorrencias(ArrayList<Ocorrencia> ocorrencias) {
		this.ocorrencias = ocorrencias;
	}


	public ArrayList<Aluno> getAlunos() {
		return alunos;
	}


	public void setAlunos(ArrayList<Aluno> alunos) {
		this.alunos = alunos;
	}
	
	
	//metodos
	//ConfirmaOcorrencia
	public boolean ConfirmaOcorrencia(Aluno alu,Date data,String desc){
		Ocorrencia Oc = new Ocorrencia();
		if(VerificaAluno(alu.getRA())){
			Oc.setID_ocorrencia(ocorrencias.size()+1);
			Oc.setAluno(alu);
			Oc.setData_ocorrencia(data);
			Oc.setDesc_ocorrencia(desc);
			ocorrencias.add(Oc);
			return true;
		}
		return false;
	}
	
	//Verificar aluno
	public boolean VerificaAluno(String RA){
		boolean verifica = false;
		for(int i=0;i<alunos.size();i++){
			if(alunos.get(i).getRA().equals(RA)){
				verifica = true;
			}
		}
		return verifica;
	}
	
	//ListaAluno()
	public String ListaAluno(){
		
		String lista_alunos = "Lista de alunos\n";
		for(int i=0;i<alunos.size();i++){
			lista_alunos += "RA : "+alunos.get(i).getRA()+" Nome : "+alunos.get(i).getNome()+
					" Turma : "+alunos.get(i).getTurma().getNomeTurma()+"\n";
		}
		return lista_alunos;
		
	}
		
	//ListaOcorrencia()
	public String ListaOcorrencia(){
	
		String lista_ocorrencias = "Lista de Ocorrencias\n";
		
		if(ocorrencias.isEmpty()){
			return "Lista de Ocorr�ncias vazia";
		}
		
		else{
			for(int i=0;i<ocorrencias.size();i++){
					lista_ocorrencias += "ID : "+ocorrencias.get(i).getID_ocorrencia()+
										" RA : "+ocorrencias.get(i).getAluno().getRA()+
										" Turma : "+ocorrencias.get(i).getAluno().getTurma().getNomeTurma()+
										" Data : "+ocorrencias.get(i).getData_ocorrencia()+
										" Descri��o : "+ocorrencias.get(i).getDesc_ocorrencia()+
										"\n";
			}
		return lista_ocorrencias;
		}
	}	
	
	//ConsultaOcorrencia(String RA)
	public String ObtemOcorrencia(String RA){
	
		String lista_consulta_aluno = "";
		int cont_ocorrencias = 0;
		
		if(!VerificaAluno(RA)){
			return "Aluno n�o cadastrado";
		}else{
			for(int i=0;i<ocorrencias.size();i++){
				if(ocorrencias.get(i).getAluno().getRA()==RA){
					cont_ocorrencias++;
					lista_consulta_aluno+="ID : "+ocorrencias.get(i).getID_ocorrencia()+
						" RA : "+ocorrencias.get(i).getAluno().getRA()+
						" Descri��o : "+ocorrencias.get(i).getDesc_ocorrencia()+
						" Data : "+ocorrencias.get(i).getData_ocorrencia()+
						"\n";
				}
			}
		
			return "H� "+cont_ocorrencias+" ocorrencias para o aluno : "+ObtemAluno(RA).getNome()+
					"\n"+lista_consulta_aluno;
		}
	}
		
	//obtemAluno(String RA) :  Aluno
	public Aluno ObtemAluno(String RA){
		
		Aluno aluno = new Aluno();
		for (int i = 0;i<alunos.size();i++){
			if(alunos.get(i).getRA()== RA){
				aluno = alunos.get(i);
			}
		}
		return aluno;		
	}
		
	//EditarOcorrencia(ID,Aluno,Data,Descri�ao)
	public boolean ConfirmaOcorrencia(int IDOc,Aluno alu,Date data,String desc){
		
		if(alu==null){
			return false;
		}
		if(VerificaAluno(alu.getRA())){
			for(int i=0;i<ocorrencias.size();i++){
				
				if(ocorrencias.get(i).getID_ocorrencia() == IDOc){
					//alterando o aluno
					if(alu!=ocorrencias.get(i).getAluno()&&alu!=null){
						ocorrencias.get(i).setAluno(alu);
					}
					if(data!=ocorrencias.get(i).getData_ocorrencia()&&data!=null){
						ocorrencias.get(i).setData_ocorrencia(data);
					}
					if(desc!=ocorrencias.get(i).getDesc_ocorrencia()&&desc!=null){
						ocorrencias.get(i).setDesc_ocorrencia(desc);
					}
					return true;
				}
			}
		}
		return false;
	}


	
	
}
