package Controle;

import java.util.Date;
import Entidade.Aluno;
import Entidade.Ocorrencia;
import Stub.BDAluno;
import Stub.BDOcorrencia;


public class CtlOcorrencia {
	
	private BDOcorrencia ocorrencias = new BDOcorrencia();;
	private BDAluno alunos = new BDAluno();

	
	//Construtores
	
	public CtlOcorrencia(BDOcorrencia stb_BDOcorrencia, BDAluno stb_BDAluno) {
		super();
		this.ocorrencias = stb_BDOcorrencia;
		this.alunos = stb_BDAluno;
	}
	
	//Getters and setters
	public BDOcorrencia getOcorrencias() {
		return ocorrencias;
	}

	public void setOcorrencias(BDOcorrencia ocorrencias) {
		this.ocorrencias = ocorrencias;
	}
	public BDAluno getAlunos() {
		return alunos;
	}

	public void setAlunos(BDAluno alunos) {
		this.alunos = alunos;
	}
	
	
	//metodos
	//ConfirmaOcorrencia
	public boolean ConfirmaOcorrencia(Aluno alu,Date data,String desc){
		Ocorrencia Oc = new Ocorrencia();
		if(VerificaAluno(alu.getRA())){
			Oc.setID_ocorrencia(ocorrencias.getBDOcorrencia().size()+1);
			Oc.setAluno(alu);
			Oc.setData_ocorrencia(data);
			Oc.setDesc_ocorrencia(desc);
			ocorrencias.getBDOcorrencia().add(Oc);
			return true;
		}
		return false;
	}
	
	//Verificar aluno
	public boolean VerificaAluno(String RA){
		boolean verifica = false;
		for(int i=0;i<alunos.getBDAluno().size();i++){
			if(alunos.getBDAluno().get(i).getRA().equals(RA)){
				verifica = true;
			}
		}
		return verifica;
	}
	
	//ListaAluno()
	public String ListaAluno(){
		
		String lista_alunos = "Lista de alunos\n";
		for(int i=0;i<alunos.getBDAluno().size();i++){
			lista_alunos += "RA : "+alunos.getBDAluno().get(i).getRA()+" Nome : "+alunos.getBDAluno().get(i).getNome()+
					" Turma : "+alunos.getBDAluno().get(i).getTurma().getNomeTurma()+"\n";
		}
		return lista_alunos;
		
	}
		
	//ListaOcorrencia()
	public String ListaOcorrencia(){
	
		String lista_ocorrencias = "Lista de Ocorrencias\n";
		
		if(ocorrencias.getBDOcorrencia().isEmpty()){
			return "Lista de Ocorr�ncias vazia";
		}
		
		else{
			for(int i=0;i<ocorrencias.getBDOcorrencia().size();i++){
					lista_ocorrencias += "ID : "+ocorrencias.getBDOcorrencia().get(i).getID_ocorrencia()+
										" RA : "+ocorrencias.getBDOcorrencia().get(i).getAluno().getRA()+
										" Turma : "+ocorrencias.getBDOcorrencia().get(i).getAluno().getTurma().getNomeTurma()+
										" Data : "+ocorrencias.getBDOcorrencia().get(i).getData_ocorrencia()+
										" Descri��o : "+ocorrencias.getBDOcorrencia().get(i).getDesc_ocorrencia()+
										"\n";
			}
		return lista_ocorrencias;
		}
	}	
	
	//ConsultaOcorrencia(String RA)
	public String ObtemOcorrencia(String RA){
	
		String lista_consulta_aluno = "";
		int cont_ocorrencias = 0;
		
		if(!VerificaAluno(RA)){
			return "Aluno n�o cadastrado";
		}else{
			for(int i=0;i<ocorrencias.getBDOcorrencia().size();i++){
				if(ocorrencias.getBDOcorrencia().get(i).getAluno().getRA()==RA){
					cont_ocorrencias++;
					lista_consulta_aluno+="ID : "+ocorrencias.getBDOcorrencia().get(i).getID_ocorrencia()+
						" RA : "+ocorrencias.getBDOcorrencia().get(i).getAluno().getRA()+
						" Descri��o : "+ocorrencias.getBDOcorrencia().get(i).getDesc_ocorrencia()+
						" Data : "+ocorrencias.getBDOcorrencia().get(i).getData_ocorrencia()+
						"\n";
				}
			}
		
			return "H� "+cont_ocorrencias+" ocorrencias para o aluno : "+ObtemAluno(RA).getNome()+
					"\n"+lista_consulta_aluno;
		}
	}
		
	//obtemAluno(String RA) :  Aluno
	public Aluno ObtemAluno(String RA){
		
		Aluno aluno = new Aluno();
		for (int i = 0;i<alunos.getBDAluno().size();i++){
			if(alunos.getBDAluno().get(i).getRA()== RA){
				aluno = alunos.getBDAluno().get(i);
			}
		}
		return aluno;		
	}
		
	//EditarOcorrencia(ID,Aluno,Data,Descri�ao)
	public boolean ConfirmaOcorrencia(int IDOc,Aluno alu,Date data,String desc){
		
		if(alu==null){
			return false;
		}
		if(VerificaAluno(alu.getRA())){
			for(int i=0;i<ocorrencias.getBDOcorrencia().size();i++){
				
				if(ocorrencias.getBDOcorrencia().get(i).getID_ocorrencia() == IDOc){
					//alterando o aluno
					if(alu!=ocorrencias.getBDOcorrencia().get(i).getAluno()&&alu!=null){
						ocorrencias.getBDOcorrencia().get(i).setAluno(alu);
					}
					if(data!=ocorrencias.getBDOcorrencia().get(i).getData_ocorrencia()&&data!=null){
						ocorrencias.getBDOcorrencia().get(i).setData_ocorrencia(data);
					}
					if(desc!=ocorrencias.getBDOcorrencia().get(i).getDesc_ocorrencia()&&desc!=null){
						ocorrencias.getBDOcorrencia().get(i).setDesc_ocorrencia(desc);
					}
					return true;
				}
			}
		}
		return false;
	}
}
