package Controle;

import java.util.Date;
import Entidade.Aluno;
import Entidade.Turma;
import Stub.BDAluno;
import Stub.BDTurma;


public class CtlAluno {
	
	private BDAluno alunos = new BDAluno();
	private BDTurma turmas = new BDTurma();
	
	
	public CtlAluno(BDAluno alunos, BDTurma turmas) {
		super();
		this.alunos = alunos;
		this.turmas = turmas;
	}
	
	//Construtores
	
	public CtlAluno(BDAluno alunos) {
		super();
		this.alunos = alunos;
	}
	
	//Getters and Setters
	
	public BDAluno getAlunos() {
		return alunos;
	}

	public void setAlunos(BDAluno alunos) {
		this.alunos = alunos;
	}
	
	public BDTurma getTurmas() {
		return turmas;
	}

	public void setTurmas(BDTurma turmas) {
		this.turmas = turmas;
	}
	
	//Metodos
	
	//Cadastrar aluno a lista de alunos
	public boolean cadastrarAluno(Aluno a){
		
		if(verificaAluno(a.getRA())){return false;}
		else
			{	alunos.getBDAluno().add(a);
				return true;
			}
	}
	
	//Consultar aluno da lista
	public Aluno consultarAluno(String RA){
		
		Aluno aluno = new Aluno();
		for (int i = 0;i<alunos.getBDAluno().size();i++){
			if(alunos.getBDAluno().get(i).getRA()== RA){
				aluno = alunos.getBDAluno().get(i);
			}
		}
		return aluno;
		
	}
	
	//Editando um aluno 
	public void confirmaDados(String RA,String nome,Turma turma,
							String nomePai,String nomeMae,String telefone,
							String endereco,String escolaAnterior,Date datanascimento){
			
		for(int i=0;i<alunos.getBDAluno().size();i++){
				
			if(alunos.getBDAluno().get(i).getRA() == RA){
				
				//alterando o aluno
				//Nome
				if(nome!=alunos.getBDAluno().get(i).getNome()&&nome!=null){
					alunos.getBDAluno().get(i).setNome(nome);
				}
				//Turma
				if(turma!=alunos.getBDAluno().get(i).getTurma()&&turma!=null){
					alunos.getBDAluno().get(i).setTurma(turma);
				}
				//Nome Pai
				if(nomePai!=alunos.getBDAluno().get(i).getNomePai()&&nomePai!=null){
					alunos.getBDAluno().get(i).setNomePai(nomePai);
				}
				//Nome Mae
				if(nomeMae!=alunos.getBDAluno().get(i).getNomeMae()&&nomeMae!=null){
					alunos.getBDAluno().get(i).setNomeMae(nomeMae);
				}
				//Telefone
				if(telefone!=alunos.getBDAluno().get(i).getTelefone()&&telefone!=null){
					alunos.getBDAluno().get(i).setTelefone(telefone);
				}
				//Endereco
				if(endereco!=alunos.getBDAluno().get(i).getEndereco()&&endereco!=null){
					alunos.getBDAluno().get(i).setEndereco(endereco);
				}	
				//Escola Anterior
				if(escolaAnterior!=alunos.getBDAluno().get(i).getEscolaAnterior()&&escolaAnterior!=null){
					alunos.getBDAluno().get(i).setEscolaAnterior(escolaAnterior);
				}
				//Data nascimento
				if(datanascimento!=alunos.getBDAluno().get(i).getDatanascimento()&&datanascimento!=null){
					alunos.getBDAluno().get(i).setDatanascimento(datanascimento);
				}
			
			}
		}
			
	}
	
	
	//Excluindo um aluno da lista de alunos
	public void excluirAluno(String RA){
		for(int i=0;i<alunos.getBDAluno().size();i++){
				
			if(alunos.getBDAluno().get(i).getRA() == RA){
				//excluindo o aluno
				alunos.getBDAluno().remove(i);
			}
		}
	}
	
	public boolean verificaAluno(String RA){
		boolean verifica = false;
		for(int i=0;i<alunos.getBDAluno().size();i++){
			if(alunos.getBDAluno().get(i).getRA().equals(RA)){
				verifica = true;
			}
		}
		return verifica;
	}
	public boolean verificaTurma(String nomeTurma){
		boolean verifica = false;
		for(int i=0;i<turmas.getBDTurma().size();i++){
			if(turmas.getBDTurma().get(i).getNomeTurma().equals(nomeTurma)){
				verifica = true;
			}
		}
		return verifica;
	}
	
	public Turma obtemTurma(String nome){
		Turma turma = new Turma();
		for(int i=0;i<turmas.getBDTurma().size();i++){
			if(turmas.getBDTurma().get(i).getNomeTurma().equals(nome)){
				turma = turmas.getBDTurma().get(i);
			}
		}
		return turma;
	}
	
	public BDAluno obtemAlunos(){
		return alunos;
	}
	
	//toString
	@Override
	public String toString(){
		String res = "\n";
		
		for(int i=0;i<alunos.getBDAluno().size();i++){
			res+=alunos.getBDAluno().get(i);
				 
		}		
		return res;
	}

	
}
