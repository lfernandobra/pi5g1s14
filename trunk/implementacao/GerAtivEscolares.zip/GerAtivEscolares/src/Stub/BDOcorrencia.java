package Stub;

import java.util.ArrayList;

import Entidade.Ocorrencia;

public class BDOcorrencia {
	private ArrayList<Ocorrencia> BDOcorrencia = new ArrayList<Ocorrencia>();

	public ArrayList<Ocorrencia> getBDOcorrencia() {
		return BDOcorrencia;
	}

	public void setBDOcorrencia(ArrayList<Ocorrencia> stb_BDOcorrencia) {
		BDOcorrencia = stb_BDOcorrencia;
	}
	
}
