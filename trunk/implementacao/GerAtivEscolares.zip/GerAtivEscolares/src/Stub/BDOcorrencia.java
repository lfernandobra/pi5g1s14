package Stub;

import java.util.ArrayList;

import Entidade.Ocorrencia;

public class BDOcorrencia {
	private ArrayList<Ocorrencia> BDOcorrencia = new ArrayList<Ocorrencia>();

	public ArrayList<Ocorrencia> getBDOcorrencia() {
		return BDOcorrencia;
	}

	public void setBDOcorrencia(ArrayList<Ocorrencia> stb_BDOcorrencia) {
		BDOcorrencia = stb_BDOcorrencia;
	}

	@Override
	public String toString() {
		String lista_ocorrencias = "Lista de ocorr�ncias\n";
		for(int i=0;i<BDOcorrencia.size();i++){
			lista_ocorrencias+="| ID : "+BDOcorrencia.get(i).getID_ocorrencia()+" | Turma : "+BDOcorrencia.get(i).getAluno().getTurma().getNomeTurma()+
							   " | RA : "+BDOcorrencia.get(i).getAluno().getRA()+" | Nome : "+BDOcorrencia.get(i).getAluno().getNome()+	
							   " | Descri��o : "+BDOcorrencia.get(i).getDesc_ocorrencia()+"\n";
		}
		return lista_ocorrencias;
	}
	
}
