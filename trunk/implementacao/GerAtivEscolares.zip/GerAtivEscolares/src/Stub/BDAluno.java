package Stub;

import java.util.ArrayList;

import Entidade.Aluno;

public class BDAluno {
	private ArrayList<Aluno> BDAluno = new ArrayList<Aluno>();

	public ArrayList<Aluno> getBDAluno() {
		return BDAluno;
	}

	public void setBDAluno(ArrayList<Aluno> stb_BDAluno) {
		BDAluno = stb_BDAluno;
	}

	@Override
	public String toString() {
		String lista_alunos = "Lista de alunos\n";
		for(int i=0;i<BDAluno.size();i++){
			lista_alunos+="Nome : "+BDAluno.get(i).getNome()+" RA : "+BDAluno.get(i).getRA()+" Turma : "+BDAluno.get(i).getTurma();
		}
		return lista_alunos;
	}
	
	
}
