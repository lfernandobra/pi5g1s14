package Stub;

import java.util.ArrayList;

import Entidade.Aluno;

public class BDAluno {
	private ArrayList<Aluno> BDAluno = new ArrayList<Aluno>();

	public ArrayList<Aluno> getBDAluno() {
		return BDAluno;
	}

	public void setBDAluno(ArrayList<Aluno> stb_BDAluno) {
		BDAluno = stb_BDAluno;
	}
	
	
}
