package Stub;

import java.util.ArrayList;

import Entidade.Turma;

public class BDTurma {
	private ArrayList<Turma> BDTurma = new ArrayList<Turma>();

	public ArrayList<Turma> getBDTurma() {
		return BDTurma;
	}

	public void setBDTurma(ArrayList<Turma> bDTurma) {
		BDTurma = bDTurma;
	}

	@Override
	public String toString() {
		String lista_turmas = "Lista de turmas\n";
		for(int i=0;i<BDTurma.size();i++){
			lista_turmas+="Nome : "+BDTurma.get(i).getNomeTurma()+" Ano : "+BDTurma.get(i).getAnoTurma()+"\n";
		}
		return lista_turmas;
	}

	
}
