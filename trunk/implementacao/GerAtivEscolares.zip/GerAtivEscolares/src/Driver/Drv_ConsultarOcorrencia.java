package Driver;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import Controle.CtlOcorrencia;
import Entidade.Aluno;
import Entidade.Ocorrencia;
import Entidade.Turma;
import Stub.BDAluno;
import Stub.BDOcorrencia;


public class Drv_ConsultarOcorrencia {

	private static String RA;
	private static CtlOcorrencia Controle;
	private static Date dataOcorrencia;
	
	//1: SolicitaOcorrencia()
	public static String SolicitaOcorrencia(){
		//2: ListaOcorrencia() //3:listaOcorrencia[]
		return Controle.ListaOcorrencia();		
	}
	//4: ConsultaOcorrencia(RA)
	public static String ConsultarOcorrencia(String RA){
		return Controle.ObtemOcorrencia(RA);
	}
	
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		//Stub BDOcorrencia e BDAluno
		BDOcorrencia Stb_BDOcorrencia = new BDOcorrencia();
		BDAluno Stb_BDAluno = new BDAluno();		
		
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
		// instanciando turma
		
		Turma Stb_turmaA = new Turma ("B","2014");
					
		// instanciando alunos com seus respectivos parametros
		
		Date dataNascimento = formatador.parse("24/04/1998");
				
		Aluno Stb_alunoA = new Aluno("1","Julia",Stb_turmaA,"Rodrigo Watanabe",
						 "Sara Araujo","+5519900000000","Rua Europa numero 123",
						 "EEPSG ABC",dataNascimento);
		Aluno Stb_alunoB = new Aluno("2","Tiago",Stb_turmaA,"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",dataNascimento);
		Stb_BDAluno.getBDAluno().add(Stb_alunoA);
		Stb_BDAluno.getBDAluno().add(Stb_alunoB);
		
		
		
		dataOcorrencia = formatador.parse("24/04/2014");
		
		Ocorrencia a = new Ocorrencia(Stb_BDOcorrencia.getBDOcorrencia().size()+1,Stb_alunoA,dataOcorrencia,"Matou aula");
		Stb_BDOcorrencia.getBDOcorrencia().add(a);
		Ocorrencia b = new Ocorrencia(Stb_BDOcorrencia.getBDOcorrencia().size()+1,Stb_alunoB,dataOcorrencia,"Desrespeito o professor");
		Stb_BDOcorrencia.getBDOcorrencia().add(b);
				
		//Instanciando a classe controle Ocorrencia
		Controle = new CtlOcorrencia(Stb_BDOcorrencia,Stb_BDAluno);
		
		
		//1: SolicitaOcorrencia()
		if(Controle.getOcorrencias().getBDOcorrencia().isEmpty()){
			System.out.println("N�o constam ocorrencias cadastradas");
		}else{System.out.println(SolicitaOcorrencia());}
		
		//4: ConsultaOcorrencia(String RA)
		RA = "2";
		
		System.out.println(ConsultarOcorrencia(RA));
						

	}

}
