package Driver;
import Controle.CtlTurma;
import Entidade.Turma;
import Stub.BDTurma;


public class Drv_ConsultarTurma {

	/**
	 * @param args
	 */
	private static CtlTurma Controle;
	
	// 1 - selecionaConsultarTurma(String selecao)
	public static boolean selecionaConsultarTurma(String selecao){
		if(selecao == "1"){
			return true;
		}
		return false;
	}
	// 2. consultaTurmas() : BDTurma
	public static BDTurma consultaTurmas(){
		//3. listaTurmas() 
		return Controle.listaTurmas();
	}
	
	//4. consultaTurma(String nome) : Turma
	public static Turma consultarTurma(String nome){
		
		//5. verificaTurma(nome)
		if(Controle.verificaTurma(nome)){
			//6. consultarTurma
			return Controle.consultarTurma(nome);
		}else{return null;}
			
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		Turma Stb_turmaC = new Turma("C","2012");
						
		//BDTurmas Stub
		BDTurma Stb_BDTurmas = new BDTurma();
		Stb_BDTurmas.getBDTurma().add(Stb_turmaA);
		Stb_BDTurmas.getBDTurma().add(Stb_turmaB);
		Stb_BDTurmas.getBDTurma().add(Stb_turmaC);
				
				
				
		Controle = new CtlTurma(Stb_BDTurmas);
		
				
		if(Controle.getTurmas().getBDTurma().isEmpty()){
			System.out.println("N�o constam turmas cadastradas");
		}else{
			String selecao = "1";
			// 1 - selecionaConsultarTurma(String selecao)
			if(selecionaConsultarTurma(selecao)){
				// 2. consultaTurmas() : BDTurma
				System.out.println(consultaTurmas());
				String nomeTurma = "A";
				//4. consultaTurma(String nomeTurma)
				if(consultarTurma(nomeTurma)!=null){
					System.out.println("Resultado da consulta de turma \n"+consultarTurma(nomeTurma));
				}else{System.out.println("Turma n�o cadastrada");}
			}	
		}
	}

}
