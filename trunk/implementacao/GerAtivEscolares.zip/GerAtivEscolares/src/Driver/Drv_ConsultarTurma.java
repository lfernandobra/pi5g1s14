package Driver;
import Controle.CtlTurma;
import Entidade.Turma;


public class Drv_ConsultarTurma {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1. SelecionaConsultaTurmas
		//2. VerificaTurmas(Turmas:String)
		//3. ObtemTurmas()
		CtlTurma Stb_CtrlTurmas = new CtlTurma();
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		//4. DigitaidTurma()
		//5. CriaTurma()
		//6. VerificaTurma()
		System.out.println(Stb_CtrlTurmas.obtemTurma("B"));

				
	}

}
