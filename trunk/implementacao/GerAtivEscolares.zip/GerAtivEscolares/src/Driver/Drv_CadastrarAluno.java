package Driver;
import java.util.Date;

import Controle.CtlAluno;
import Entidade.Aluno;
import Entidade.Turma;
import Stub.BDAluno;
import Stub.BDTurma;


public class Drv_CadastrarAluno {

	/**
	 * @param args
	 */
	private static CtlAluno ControleAluno;
	private static Aluno aluno = new Aluno();
	
	// 1 - selecionaCadastrarAluno
	public static boolean selecionaCadastrarAluno(String selecao){
		if(selecao == "1"){
			return true;
		}
		return false;
	}
	
	// 2 - insereDados
	public static Aluno insereDados(String rA, String nome, String nomePai,
			String nomeMae, String telefone, String endereco,
			String escolaAnterior, Date datanascimento){
		
		
		aluno.setRA(rA);
		aluno.setNome(nome);
		aluno.setNomePai(nomePai);
		aluno.setNomeMae(nomeMae);
		aluno.setTelefone(telefone);
		aluno.setDatanascimento(datanascimento);
		aluno.setEndereco(endereco);
		aluno.setEscolaAnterior(escolaAnterior);
		
		return aluno;
		
	}
	// 3 - selecionarTurma
	public static BDTurma selecionarTurma(){
		// 4 - getTurmas()
		return ControleAluno.getTurmas();
	}
	// 6 - escolherTurma
	public static void escolherTurma(String nome){
		// 7 - verificaTurma
		if(ControleAluno.verificaTurma(nome)){
			aluno.setTurma(ControleAluno.obtemTurma(nome));
			//8 - cadastrarAluno()
			ControleAluno.cadastrarAluno(aluno);
			System.out.println("Aluno cadastrado com sucesso\n");
			System.out.println(ControleAluno.obtemAlunos());
		}else{System.out.println("Turma n�o encontrada");}
			
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Stub BDTurma e BDAluno
		BDTurma Stb_BDTurma = new BDTurma();
		BDAluno Stb_BDAluno = new BDAluno(); 
		
		Turma A = new Turma("A","2014");
		Turma B = new Turma("B","2015");
		Stb_BDTurma.getBDTurma().add(A);
		Stb_BDTurma.getBDTurma().add(B);
		
		
		ControleAluno = new CtlAluno(Stb_BDAluno,Stb_BDTurma);
		
		// 1 - SelecionaMatricula
		String selecao = "1";
		if(Drv_CadastrarAluno.selecionaCadastrarAluno(selecao)){
			// 2 - InsereDados
			Drv_CadastrarAluno.insereDados("1","Julia","Rodrigo Watanabe",
					 "Sara Araujo","+5519900000000","Rua Europa numero 123",
					 "EEPSG ABC",null);
			// 3 - Selecionar Turma
			System.out.println(Drv_CadastrarAluno.selecionarTurma());
			// 5 - Escolher Turma
			String nomeTurma = "A";
			Drv_CadastrarAluno.escolherTurma(nomeTurma);
		}
		else {System.out.println("Op��o Invalida");}
		

	}

}
