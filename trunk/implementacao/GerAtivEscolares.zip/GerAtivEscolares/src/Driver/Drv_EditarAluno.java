package Driver;
import java.util.Date;
import Controle.CtlAluno;
import Entidade.Aluno;
import Entidade.Turma;
import Stub.BDAluno;
import Stub.BDTurma;

public class Drv_EditarAluno {
	
	private static CtlAluno ControleAluno;
	private static Aluno aluno = new Aluno();
	
	
	//1. selecionaEditarAluno	
	public static boolean selecionaEditarAluno(String selecao){
		if(selecao == "1"){
			return true;
		}
		return false;
	}
	//2. inserirRA(String RA)
	private static boolean inserirRA(String RA){
		//3. verificaAluno(String RA)
		if(ControleAluno.verificaAluno(RA)){
			//4. consultarAluno(RA)
			aluno = ControleAluno.consultarAluno(RA);
			System.out.println(ControleAluno.consultarAluno(RA));
			return true;
		}
		return false;
	}
	// 4 - selecionarTurma()
		public static BDTurma selecionarTurma(){
			//5 - getTurmas
			return ControleAluno.getTurmas();
		}
	
	//6 - editarAluno(Aluno alu,String nome,Turma turma,String nomePai,String nomeMae, String telefone, String endereco,String escolaAnterior, Date datanascimento)
	private static void editarAluno(Aluno alu,String nome,Turma turma,String nomePai,
									String nomeMae, String telefone, String endereco,
									String escolaAnterior, Date datanascimento){
		//7. confirmaDados
		ControleAluno.confirmaDados(alu.getRA(),nome,turma,nomePai,nomeMae,telefone,endereco,
								  escolaAnterior,datanascimento);
		System.out.println("Dados editados com sucesso");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		Turma Stb_turmaC = new Turma("C","2012");
		
		//BDTurmas Stub
		BDTurma Stb_BDTurmas = new BDTurma();
		Stb_BDTurmas.getBDTurma().add(Stb_turmaA);
		Stb_BDTurmas.getBDTurma().add(Stb_turmaB);
		Stb_BDTurmas.getBDTurma().add(Stb_turmaC);
		
		// instanciando alunos 
		//BDAlunos
		BDAluno Stb_BDAlunos = new BDAluno();
		
		Aluno Stb_alunoA = new Aluno("1","Julia",Stb_turmaB,"Rodrigo Watanabe",
						 "Sara Araujo","+5519900000000","Rua Europa numero 123",
						 "EEPSG ABC",null);
		Aluno Stb_alunoB = new Aluno("2","Marina",Stb_turmaA,"Paulo Henrique",
						 "Camila","+5519900000000","Rua Oceania numero 123",
						 "EEPSG ABC",null);			
		Stb_BDAlunos.getBDAluno().add(Stb_alunoA);
		Stb_BDAlunos.getBDAluno().add(Stb_alunoB);
		
		ControleAluno = new CtlAluno(Stb_BDAlunos,Stb_BDTurmas);
		
		String selecao = "1";
		String RA = "1";
		
		//1. selecionaEditarAluno
		if(selecionaEditarAluno(selecao)){
			//2. inserirRA(String RA)
			if(inserirRA(RA)){
				System.out.println("Lista de turmas\n"+selecionarTurma());
				//6 - editarAluno(Aluno alu,String nome,Turma turma,String nomePai,String nomeMae, String telefone, String endereco,String escolaAnterior, Date datanascimento)
				Turma A = new Turma("C","2015");
				editarAluno(aluno, "Luiza", A, "Leonardo", "Bruna", "33444511", "Rua Z","Monteiro Lobato", null);
				System.out.println(ControleAluno.consultarAluno(RA));
			}else{
				System.out.println("Aluno n�o encontrado");
			}
		}
		else{System.out.println("Op��o Invalida");}
	}

}
