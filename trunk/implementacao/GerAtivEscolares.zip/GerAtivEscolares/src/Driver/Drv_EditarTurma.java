package Driver;
import Controle.CtlTurma;
import Entidade.Turma;
import Stub.BDTurma;


public class Drv_EditarTurma {

	private static CtlTurma ControleTurma;
	private static Turma turma = new Turma();
	
	// 1 - selecionaEditarTurma(String selecao)
		public static boolean selecionaEditarTurma(String selecao){
			if(selecao == "1"){
				return true;
			}
			return false;
		}
	
	//2. inserirNomeTurma(String RA)
	private static boolean inserirNomeTurma(String nome){
			//3. verificarTurma(String nome)
			if(ControleTurma.verificaTurma(nome)){
				//4. consultarTurma(nome)
				turma=(ControleTurma.consultarTurma(nome));
				System.out.println(turma);
				return true;
			}
			return false;
	}
	//5. editarTurma
	private static void editarTurma(String nome,String ano){
		//6 . confirmaDados
		ControleTurma.confirmaDados(turma,nome,ano);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		Turma Stb_turmaC = new Turma("C","2012");
				
		//BDTurmas Stub
		BDTurma Stb_BDTurmas = new BDTurma();
		Stb_BDTurmas.getBDTurma().add(Stb_turmaA);
		Stb_BDTurmas.getBDTurma().add(Stb_turmaB);
		Stb_BDTurmas.getBDTurma().add(Stb_turmaC);
		
		
		
		ControleTurma = new CtlTurma(Stb_BDTurmas);
		
		String nomeTurma = "A";
		String nome = "D";
		String ano = "2016";
		String selecao = "1";
		
		// 1 - selecionaEditarTurma(String selecao)
		if(selecionaEditarTurma(selecao)){
			//2. inserirNomeTurma(String nomeTurma)
			if(inserirNomeTurma(nomeTurma)){
				//5. editarTurma
				editarTurma(nome,ano);
				System.out.println(ControleTurma.listaTurmas()+"\nTurma editada com sucesso");
			}else{System.out.println("Turma n�o encontrada");}
		}
		else{System.out.println("Op��o Invalida");} 
	}
	

}
