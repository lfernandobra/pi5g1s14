package Driver;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import Controle.CtlOcorrencia;
import Entidade.Aluno;
import Entidade.Turma;
import Stub.BDAluno;
import Stub.BDOcorrencia;


public class Drv_CadastrarOcorrencia {
	private static CtlOcorrencia ControleOcorrencia;
	private static String RA;
	private static String descricao;
	private static Date dataOcorrencia;
	private static Aluno alunoaux;
	
	public static Aluno solicitaAluno(String RA){
		//2. ListaAluno()
		System.out.println(ControleOcorrencia.listaAluno());
		//3. listaAluno[] = obtemAluno(RA)
		return ControleOcorrencia.obtemAluno(RA);
	}
	public static boolean cadastrarOcorrencia(Aluno alu,Date data,String desc){
		//4. ListaOcorrencia
		System.out.println(ControleOcorrencia.listaOcorrencia());
		//6. ConfirmaOcorrencia(ocorrencia)
		return ControleOcorrencia.confirmaOcorrencia(alu,data,desc);
	}
	
			
	public static void main(String[] args) throws ParseException{
		// TODO Auto-generated method stub
		
		//Stub BDOcorrencia e BDAluno
		BDOcorrencia Stb_BDOcorrencia = new BDOcorrencia();
		BDAluno Stb_BDAluno = new BDAluno(); 
					
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
		// instanciando turma
		
		Turma Stb_turmaA = new Turma ("A","2014");
		
		// instanciando alunos com seus respectivos parametros
		
		Date dataNascimento = formatador.parse("24/04/1998");
		
		Aluno Stb_alunoA = new Aluno("1","Julia Yukari",Stb_turmaA,"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",dataNascimento);
		Stb_BDAluno.getBDAluno().add(Stb_alunoA);
				
		
		
		//Instanciando a classe controle Ocorrencia
		ControleOcorrencia = new CtlOcorrencia(Stb_BDOcorrencia,Stb_BDAluno);
		RA = "1";
		
		alunoaux = new Aluno();
		
		
		//1. SolicitaAluno()
		if(ControleOcorrencia.verificaAluno(RA)){
			alunoaux=solicitaAluno(RA);
			//5. CadastrarOcorrencia
			descricao="Desrespeitou o professor";
			dataOcorrencia = formatador.parse("24/04/2014");
			
			System.out.println(cadastrarOcorrencia(alunoaux,dataOcorrencia,descricao)?"Ocorr�ncia cadastrada":"Ocorr�ncia n�o cadastrada");
			
			//7. SalvaOcorrencia
			System.out.println(ControleOcorrencia.listaOcorrencia());
		}else {
			System.out.println("Aluno n�o cadastrado , n�o possivel o cadastro da ocorrencia");
		}
		//
		
		
		

	}

}
