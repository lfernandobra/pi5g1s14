package Driver;
import Controle.CtlAluno;
import Entidade.Aluno;
import Entidade.Turma;
import Stub.BDAluno;
import Stub.BDTurma;

public class Drv_ConsultarAluno {

	/**
	 * @param args
	 */
	private static CtlAluno ControleAluno;
		
	//1 - selecionarConsultar()
	
	public static boolean selecionaConsultar(String selecao){
		if(selecao == "1"){
			return true;
		}
		return false;
	}
	
	//2 - InsereRA()
	public static void insereRA(String RA){
		//3 - VerificaAluno()
		if(ControleAluno.verificaAluno(RA)){
			//4 - consultarAluno(RA)
			System.out.println(ControleAluno.consultarAluno(RA));
		}else{System.out.println("Aluno n�o encontrado");}
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Stub BDTurma e BDAluno
		BDTurma Stb_BDTurma = new BDTurma();
		 
			
		Turma A = new Turma("A","2014");
		Turma B = new Turma("B","2015");
		Stb_BDTurma.getBDTurma().add(A);
		Stb_BDTurma.getBDTurma().add(B);
		
		// instanciando alunos 
		//BDAlunos
		BDAluno Stb_BDAlunos = new BDAluno();
				
		Aluno Stb_alunoA = new Aluno("1","Julia",A,"Rodrigo Watanabe",
									"Sara Araujo","+5519900000000","Rua Europa numero 123",
									"EEPSG ABC",null);
		Aluno Stb_alunoB = new Aluno("2","Marina",B,"Paulo Henrique",
									"Camila","+5519900000000","Rua Oceania numero 123",
									"EEPSG ABC",null);			
		Stb_BDAlunos.getBDAluno().add(Stb_alunoA);
		Stb_BDAlunos.getBDAluno().add(Stb_alunoB);
				
				
		ControleAluno = new CtlAluno(Stb_BDAlunos,Stb_BDTurma);
				
		String selecao = "1";
		String RA = "1";
		
		//1. SelecionarConsultar()
		if(selecionaConsultar(selecao)){
		   //2 - InsereRA()
			insereRA(RA);
		}
		else{
			System.out.println("Op��o invalida");	
		}		

	}

}
