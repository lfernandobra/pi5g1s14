package Driver;
import Controle.CtlTurma;
import Entidade.Turma;
import Stub.BDTurma;


public class Drv_CadastrarTurma {

	/**
	 * @param args
	 */
	private static CtlTurma ControleTurma;
	private static Turma turma;
	
	// 1 - selecionaCadastrarTurma
	public static boolean selecionaCadastrarTurma(String selecao){
		if(selecao == "1"){
			return true;
		}
		return false;
	}
	// 2 - insereTurma
	public static void insereTurma(String nomeTurma,String anoTurma){
		turma = new Turma();
		
		turma.setNomeTurma(nomeTurma);
		turma.setAnoTurma(anoTurma);
		// 3 - cadastrarTurma
		ControleTurma.cadastrarTurma(turma);
	}
	// 4 - VisualizarTurmas
	public static BDTurma visualizarTurmas(){
		// 5 - listaTurmas
		return ControleTurma.listaTurmas();
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BDTurma Stb_BDTurma = new BDTurma();
		
		ControleTurma = new CtlTurma(Stb_BDTurma);
		
		//1. SelecionaTurmas
		String selecao = "1";
		if(selecionaCadastrarTurma(selecao)){
		  // 2 - InsereTurma
		  insereTurma("A","2014");
		// 4 - VisualizarTurmas
		  System.out.println(visualizarTurmas()); }
		else{System.out.println("Op��o invalida");};
		
		
		

	}

}
