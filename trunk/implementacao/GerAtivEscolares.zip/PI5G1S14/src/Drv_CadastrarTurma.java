
public class Drv_CadastrarTurma {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1. SelecionaTurmas
		//2. VerificaTurmas(Turmas:String)
		Mod_CtrlTurma Stb_CtrlTurmas = new Mod_CtrlTurma();
		//3. ObtemTurmas()
		//4. SelecionaNovaTurma()
		//5. CriaTurma()
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
		//6. InserirTurma()
		//7. VerificaTurma()
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		//8. SalvaTurma()
		
		//Exibindo o BDTurmas
		System.out.println(Stb_CtrlTurmas);
		
		

	}

}
