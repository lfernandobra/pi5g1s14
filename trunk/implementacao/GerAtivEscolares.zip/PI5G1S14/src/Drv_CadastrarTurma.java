
public class Drv_CadastrarTurma {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1. SelecionaTurmas
		//2. VerificaTurmas(Turmas:String)
		CtlTurma Stb_CtrlTurmas = new CtlTurma();
		//3. ObtemTurmas()
		//4. SelecionaNovaTurma()
		//5. CriaTurma()
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		//6. InserirTurma()
		//7. VerificaTurma()
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		//8. SalvaTurma()
		
		//Exibindo o BDTurmas
		System.out.println(Stb_CtrlTurmas);
		
		

	}

}
