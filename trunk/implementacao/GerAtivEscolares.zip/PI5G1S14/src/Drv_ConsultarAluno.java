public class Drv_ConsultarAluno {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		Turma Stb_turmaC = new Turma("C","2012");
				
		//BDTurmas Stub
		CtlTurma Stb_CtrlTurmas = new CtlTurma();
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaC);
				
		// instanciando alunos 
		Aluno Stb_alunoA = new Aluno("1","Julia",Stb_CtrlTurmas.obtemTurma("C"),"Rodrigo Watanabe",
						 "Sara Araujo","+5519900000000","Rua Europa numero 123",
						 "EEPSG ABC",null);
		Aluno Stb_alunoB = new Aluno("2","Marina",Stb_CtrlTurmas.obtemTurma("B"),"Paulo Henrique",
						 "Camila","+5519900000000","Rua Oceania numero 123",
						 "EEPSG ABC",null);
		// instanciado a um objeto da classe controle de alunos
		CtlAluno CtrlAluno = new CtlAluno();
		CtrlAluno.inserirAluno(Stb_alunoA);
		CtrlAluno.inserirAluno(Stb_alunoB);
		
		//1. SelecConsultar()
		//2. InsereRA()
		//3. ConsultaAluno(RA:String)
		//4. ObtemAluno() : Aluno
		System.out.println(CtrlAluno.obtemAluno("2"));
				

	}

}
