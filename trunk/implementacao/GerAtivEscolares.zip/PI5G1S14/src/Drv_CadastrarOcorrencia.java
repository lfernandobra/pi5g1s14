

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;



public class Drv_CadastrarOcorrencia {

			
	public static void main(String[] args) throws ParseException{
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
				
		//BDTurmas Stub
		CtlTurma Stb_CtrlTurmas = new CtlTurma();
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		
		// instanciando alunos com seus respectivos parametros (RA,Nome,Turma)
		Aluno Stb_alunoA = new Aluno("1","Julia",Stb_CtrlTurmas.obtemTurma("A"),"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",null);
		Aluno Stb_alunoB = new Aluno("2","Marina",Stb_CtrlTurmas.obtemTurma("B"),"Paulo Henrique",
				 "Camila","+5519900000000","Rua Oceania numero 123",
				 "EEPSG ABC",null);
		
		// instanciado um objeto da classe controle de alunos
		CtlAluno CtrlAluno = new CtlAluno();
		
		
		// inserindo alunos a lista de alunos
		CtrlAluno.inserirAluno(Stb_alunoA);
		CtrlAluno.inserirAluno(Stb_alunoB);
		
				
		//Formatador para o atributo tipo date
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
	    	
		//1. Solicita Aluno()
		
		String RA = "1"; 
				
		//2. ListaAluno()

		//3. listaAluno[]obtemAluno()
		
		Aluno A1 = CtrlAluno.obtemAluno(RA);
		
		//4. listaOcorrencia[] 
		CtlOcorrencia CtrlOcorrencia = new CtlOcorrencia();
		
		//5. CadastraOcorrencia()
		
		Date dataA1 = formatador.parse("24/04/2014");
		
		Ocorrencia Oc1 = new Ocorrencia (A1,dataA1,"Matou aula");
		
		//6. ConfirmaOcorrencia() 7. SalvarOcorrencia()
		CtrlOcorrencia.inserirOcorrencia(Oc1);
		
		System.out.println(CtrlOcorrencia);
		
		
	}

}
