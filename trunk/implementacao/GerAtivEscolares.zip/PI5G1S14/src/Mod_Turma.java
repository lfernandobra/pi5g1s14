
public class Mod_Turma {

	private String nomeTurma;
	private String anoTurma;
	
	//construtores
	
	public Mod_Turma(){
		super();
	}
	
	public Mod_Turma(String nome,String ano){
		super();
		this.nomeTurma = nome;
		this.anoTurma = ano;
		
	}
	
	// Getters and Setters
	public String getNomeTurma() {
		return nomeTurma;
	}

	public void setNomeTurma(String nomeTurma) {
		this.nomeTurma = nomeTurma;
	}
	
	public String getAnoTurma() {
		return anoTurma;
	}

	public void setAnoTurma(String anoTurma) {
		this.anoTurma = anoTurma;
	}
	
	//toString
	public String toString(){
		return "Nome : "+nomeTurma+" Ano : "+anoTurma+"\n";
	}
	
}
