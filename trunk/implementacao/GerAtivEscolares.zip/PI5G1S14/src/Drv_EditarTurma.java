
public class Drv_EditarTurma {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1. SelecionaEditarTurmas()
		//2. VerificaTurmas(Turmas:String)
		//3. ObtemTurmas()
		CtlTurma Stb_CtrlTurmas = new CtlTurma();
		Turma Stb_turmaA = new Turma("A","2014");
		Turma Stb_turmaB = new Turma("B","2013");
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		//4. DigitaidTurma()
		//5. VerificaTurma(idTurma:int)
		//6. ObtemTurma():Turma
		//7. InserirAltera��o():void
		//8. VerificaAltera��o():void
		//9. SalvaAltera��o
		Stb_CtrlTurmas.editarTurma("A", "C", "2015");
		
		//Exibindo o resultado da busca no BDTurmas
		System.out.println(Stb_CtrlTurmas.obtemTurma("C"));

	}

}
