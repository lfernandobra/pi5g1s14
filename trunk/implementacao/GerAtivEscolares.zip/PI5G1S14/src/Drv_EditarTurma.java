
public class Drv_EditarTurma {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1. SelecionaEditarTurmas()
		//2. VerificaTurmas(Turmas:String)
		//3. ObtemTurmas()
		Mod_CtrlTurma Stb_CtrlTurmas = new Mod_CtrlTurma();
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		//4. DigitaidTurma()
		//5. VerificaTurma(idTurma:int)
		//6. ObtemTurma():Turma
		//7. InserirAltera��o():void
		//8. VerificaAltera��o():void
		//9. SalvaAltera��o
		Stb_CtrlTurmas.editarTurma("A", "C", "2015");
		
		//Exibindo o resultado da busca no BDTurmas
		System.out.println(Stb_CtrlTurmas.obtemTurma("C"));

	}

}
