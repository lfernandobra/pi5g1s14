package Driver;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import Controle.CtlOcorrencia;
import Entidade.Aluno;
import Entidade.Ocorrencia;


public class Drv_ConsultarOcorrencia {

	private static String RA;
	private static CtlOcorrencia Controle;
	private static Date dataOcorrencia;
	
	//1: SolicitaOcorrencia()
	public static String SolicitaOcorrencia(){
		//2: ListaOcorrencia() //3:listaOcorrencia[]
		return Controle.ListaOcorrencia();		
	}
	//4: ConsultaOcorrencia(RA)
	public static String ConsultarOcorrencia(String RA){
		return Controle.ObtemOcorrencia(RA);
	}
	
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		//BDOcorrAluno Stub
		ArrayList<Ocorrencia> Stb_BDOcorrAluno = new ArrayList<Ocorrencia>();
		ArrayList<Aluno> Stb_BDaluno = new ArrayList<Aluno>();		
					
		// instanciando alunos com seus respectivos parametros (RA,Nome,Turma)
				
		Aluno Stb_alunoA = new Aluno("1","Julia",null,"Rodrigo Watanabe",
						 "Sara Araujo","+5519900000000","Rua Europa numero 123",
						 "EEPSG ABC",null);
		Aluno Stb_alunoB = new Aluno("2","Tiago",null,"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",null);
		Stb_BDaluno.add(Stb_alunoA);
		Stb_BDaluno.add(Stb_alunoB);
		
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
		dataOcorrencia = formatador.parse("24/04/2014");
		
		Ocorrencia a = new Ocorrencia(Stb_BDOcorrAluno.size()+1,Stb_alunoA,dataOcorrencia,"Matou aula");
		Stb_BDOcorrAluno.add(a);
		Ocorrencia b = new Ocorrencia(Stb_BDOcorrAluno.size()+1,Stb_alunoB,dataOcorrencia,"Desrespeito o professor");
		Stb_BDOcorrAluno.add(b);
				
		//Instanciando a classe controle Ocorrencia
		Controle = new CtlOcorrencia(Stb_BDOcorrAluno,Stb_BDaluno);
		
		
		//1: SolicitaOcorrencia()
		if(Controle.getOcorrencias().isEmpty()){
			System.out.println("N�o constam ocorrencias cadastradas");
		}else{System.out.println(SolicitaOcorrencia());}
		
		//4: ConsultaOcorrencia(String RA)
		RA = "1";
		
		System.out.println(ConsultarOcorrencia(RA));
						

	}

}
