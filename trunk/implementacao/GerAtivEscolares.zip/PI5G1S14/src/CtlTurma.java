import java.util.ArrayList;


public class CtlTurma {
	
	private ArrayList<Turma> Stb_BDturma = new ArrayList<Turma>();
	
	// construtores
	public CtlTurma(){
		super();
	}
	
	//salvar turma
	
	public void inserirTurma(Turma t){
		Stb_BDturma.add(t);
	}
	
	//obtem turma da lista
	
	public Turma obtemTurma(String nomeTurma){
		Turma turma = new Turma();
		for (int i = 0;i<Stb_BDturma.size();i++){
			if(Stb_BDturma.get(i).getNomeTurma() == nomeTurma){
				turma = Stb_BDturma.get(i);
			}
		}
		return turma;
		
	}
	//Editando uma turma 
	public void editarTurma(String nomeTurma,String nome,String ano){
				
		for(int i=0;i<Stb_BDturma.size();i++){
					
			if(Stb_BDturma.get(i).getNomeTurma() == nomeTurma){
			//alterando o aluno
			  Stb_BDturma.get(i).setNomeTurma(nome);
			  Stb_BDturma.get(i).setAnoTurma(ano);
			}
		}
				
	}
		
		
		//Excluindo um aluno da lista de alunos
	public void excluirTurma(String nomeTurma){
		for(int i=0;i<Stb_BDturma.size();i++){
					
			if(Stb_BDturma.get(i).getNomeTurma() == nomeTurma){
			//excluindo o aluno
			  Stb_BDturma.remove(i);
			}
		}
	}
		
		
		//toString
		public String toString(){
			String res = "Lista de turmas\n";
			
			for(int i=0;i<Stb_BDturma.size();i++){
				res+=Stb_BDturma.get(i).toString();
			}		
			return res;
		}
	
}
