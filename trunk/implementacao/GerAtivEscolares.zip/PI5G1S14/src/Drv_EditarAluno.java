public class Drv_EditarAluno {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//instanciando objetos da classe Turma
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
		Mod_Turma Stb_turmaC = new Mod_Turma("C","2012");
		
		//BDTurmas Stub
		Mod_CtrlTurma Stb_CtrlTurmas = new Mod_CtrlTurma();
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaC);
		
		// instanciando alunos 
		Mod_Aluno Stb_alunoA = new Mod_Aluno("1","Julia",Stb_CtrlTurmas.obtemTurma("C"),"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",null);
		Mod_Aluno Stb_alunoB = new Mod_Aluno("2","Marina",Stb_CtrlTurmas.obtemTurma("B"),"Paulo Henrique",
				 "Camila","+5519900000000","Rua Oceania numero 123",
				 "EEPSG ABC",null);
		// instanciado a um objeto da classe controle de alunos
		Mod_CtrlAluno CtrlAluno = new Mod_CtrlAluno();
		
		CtrlAluno.inserirAluno(Stb_alunoA);
		CtrlAluno.inserirAluno(Stb_alunoB);
		//Antes da edi��o
		System.out.println("Antes da edi��o \n"+CtrlAluno.obtemAluno("1"));
		
		//1. InserirRA()
		//2. ConsultaAluno(RA:String)
		//3. ObtemAluno()
		//4. EditarAluno()
		//5. VerificaDados()
		//6. RegDados()
		//7. RegDados() BD Turmas
		CtrlAluno.editarAluno("1", "Julia Maria",Stb_CtrlTurmas.obtemTurma("A"),"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",null);
		
		//Depois da edi��o
		System.out.println("Depois da edi��o \n"+CtrlAluno.obtemAluno("1"));
		
		
		
	}

}
