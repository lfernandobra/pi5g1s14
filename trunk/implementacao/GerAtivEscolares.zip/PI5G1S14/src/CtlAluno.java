import java.util.ArrayList;
import java.util.Date;

public class CtlAluno {
	
	private ArrayList<Aluno> Stb_BDAluno = new ArrayList<Aluno>();
	
	//Construtores
	
	public CtlAluno(){
		super();
	}
		
	//metodos
	
	//salvar aluno a lista de alunos
	public void inserirAluno(Aluno a){
		Stb_BDAluno.add(a);
	}
	
	//obtem aluno da lista
	public Aluno obtemAluno(String RA){
		
		Aluno aluno = new Aluno();
		for (int i = 0;i<Stb_BDAluno.size();i++){
			if(Stb_BDAluno.get(i).getRA()== RA){
				aluno = Stb_BDAluno.get(i);
			}
		}
		return aluno;
		
	}
	
	//Editando um aluno 
	public void editarAluno(String RA,String nome,Turma turma,
							String nomePai,String nomeMae,String telefone,
							String endereco,String escolaAnterior,Date datanascimento){
			
		for(int i=0;i<Stb_BDAluno.size();i++){
				
			if(Stb_BDAluno.get(i).getRA() == RA){
			//alterando o aluno
			  Stb_BDAluno.get(i).setNome(nome);
			  Stb_BDAluno.get(i).setTurma(turma);
			  Stb_BDAluno.get(i).setNomePai(nomePai);
			  Stb_BDAluno.get(i).setNomeMae(nomeMae);
			  Stb_BDAluno.get(i).setTelefone(telefone);
			  Stb_BDAluno.get(i).setEndereco(endereco);
			  Stb_BDAluno.get(i).setEscolaAnterior(escolaAnterior);
			  Stb_BDAluno.get(i).setDatanascimento(datanascimento);
			}
		}
			
	}
	
	
	//Excluindo um aluno da lista de alunos
		public void excluirAluno(String RA){
			for(int i=0;i<Stb_BDAluno.size();i++){
				
				if(Stb_BDAluno.get(i).getRA() == RA){
					//excluindo o aluno
					Stb_BDAluno.remove(i);
				}
			}
		}
	
	
	//toString
	public String toString(){
		String res = "\n";
		
		for(int i=0;i<Stb_BDAluno.size();i++){
			res+=Stb_BDAluno.get(i);
				 
		}		
		return res;
	}
	
	
	
	
}
