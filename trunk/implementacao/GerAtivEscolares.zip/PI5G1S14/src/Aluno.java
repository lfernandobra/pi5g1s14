import java.util.Date;


public class Aluno {
	
	private String RA;
	private String Nome;
	private Turma turma;
	private String nomePai;
	private String nomeMae;
	private String telefone;
	private String endereco;
	private String escolaAnterior;
	private Date datanascimento;
	
	
	//Getters and Setters
	
	public String getRA() {
		return RA;
	}
	public void setRA(String rA) {
		RA = rA;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public Turma getTurma() {
		return turma;
	}
	public void setTurma(Turma turma) {
		this.turma = turma;
	}
	public String getNomePai() {
		return nomePai;
	}
	public void setNomePai(String nomePai) {
		this.nomePai = nomePai;
	}
	public String getNomeMae() {
		return nomeMae;
	}
	public void setNomeMae(String nomeMae) {
		this.nomeMae = nomeMae;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getEscolaAnterior() {
		return escolaAnterior;
	}
	public void setEscolaAnterior(String escolaAnterior) {
		this.escolaAnterior = escolaAnterior;
	}
	public Date getDatanascimento() {
		return datanascimento;
	}
	public void setDatanascimento(Date datanascimento) {
		this.datanascimento = datanascimento;
	}
	
	//Construtores
	
	public Aluno(){
		super();
	}
	
	public Aluno(String rA, String nome, Turma turma, String nomePai,
			String nomeMae, String telefone, String endereco,
			String escolaAnterior, Date datanascimento) {
		super();
		this.RA = rA;
		this.Nome = nome;
		this.turma = turma;
		this.nomePai = nomePai;
		this.nomeMae = nomeMae;
		this.telefone = telefone;
		this.endereco = endereco;
		this.escolaAnterior = escolaAnterior;
		this.datanascimento = datanascimento;
	}
	
	//toString
	public String toString() {
		return "RA : "+RA+
			    "\nNome : "+Nome+
				"\nTurma : "+turma+
				"\nPai : "+nomePai+
				"\nM�e : "+nomeMae+
				"\nTelefone : "+telefone+
				"\nEndere�o : "+endereco+
				"\nEscola Anterior : "+escolaAnterior+
				"\nData de nascimento : "+datanascimento+"\n";
	}	
	
}
