import java.util.ArrayList;


public class Mod_CtrlTurma {
	
	private ArrayList<Mod_Turma> Stb_turmas = new ArrayList<Mod_Turma>();
	
	// construtores
	public Mod_CtrlTurma(){
		super();
	}
	
	//salvar turma
	
	public void inserirTurma(Mod_Turma t){
		Stb_turmas.add(t);
	}
	
	//obtem turma da lista
	
	public Mod_Turma obtemTurma(String nomeTurma){
		Mod_Turma turma = new Mod_Turma();
		for (int i = 0;i<Stb_turmas.size();i++){
			if(Stb_turmas.get(i).getNomeTurma() == nomeTurma){
				turma = Stb_turmas.get(i);
			}
		}
		return turma;
		
	}
	//Editando uma turma 
	public void editarTurma(String nomeTurma,String nome,String ano){
				
		for(int i=0;i<Stb_turmas.size();i++){
					
			if(Stb_turmas.get(i).getNomeTurma() == nomeTurma){
			//alterando o aluno
			  Stb_turmas.get(i).setNomeTurma(nome);
			  Stb_turmas.get(i).setAnoTurma(ano);
			}
		}
				
	}
		
		
		//Excluindo um aluno da lista de alunos
	public void excluirTurma(String nomeTurma){
		for(int i=0;i<Stb_turmas.size();i++){
					
			if(Stb_turmas.get(i).getNomeTurma() == nomeTurma){
			//excluindo o aluno
			  Stb_turmas.remove(i);
			}
		}
	}
		
		
		//toString
		public String toString(){
			String res = "Lista de turmas\n";
			
			for(int i=0;i<Stb_turmas.size();i++){
				res+=Stb_turmas.get(i).toString();
			}		
			return res;
		}
	
}
