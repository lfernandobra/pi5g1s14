
public class Drv_ConsultarTurma {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1. SelecionaConsultaTurmas
		//2. VerificaTurmas(Turmas:String)
		//3. ObtemTurmas()
		Mod_CtrlTurma Stb_CtrlTurmas = new Mod_CtrlTurma();
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
		//4. DigitaidTurma()
		//5. CriaTurma()
		//6. VerificaTurma()
		System.out.println(Stb_CtrlTurmas.obtemTurma("B"));

				
	}

}
