import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Drv_ConsultarOcorrencia {

	/**
	 * @param args
	 * @throws ParseException 
	 */
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
						
		//BDTurmas Stub
		Mod_CtrlTurma Stb_CtrlTurmas = new Mod_CtrlTurma();
		Stb_CtrlTurmas.inserirTurma(Stb_turmaA);
		Stb_CtrlTurmas.inserirTurma(Stb_turmaB);
				
		// instanciando alunos com seus respectivos parametros (RA,Nome,Turma)
		Mod_Aluno Stb_alunoA = new Mod_Aluno("1","Julia",Stb_CtrlTurmas.obtemTurma("A"),"Rodrigo Watanabe",
				 "Sara Araujo","+5519900000000","Rua Europa numero 123",
				 "EEPSG ABC",null);
		Mod_Aluno Stb_alunoB = new Mod_Aluno("2","Marina",Stb_CtrlTurmas.obtemTurma("B"),"Paulo Henrique",
				 "Camila","+5519900000000","Rua Oceania numero 123",
				 "EEPSG ABC",null);
				
		// instanciado um objeto da classe controle de alunos
		Mod_CtrlAluno CtrlAluno = new Mod_CtrlAluno();
				
				
		// inserindo alunos a lista de alunos
		CtrlAluno.inserirAluno(Stb_alunoA);
		CtrlAluno.inserirAluno(Stb_alunoB);
				
						
		//Formatador para o atributo tipo date
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
		Mod_CtrlOcorrencia CtrlOcorrencia = new Mod_CtrlOcorrencia();
				
		Date dataA1 = formatador.parse("24/04/2014");
				
		Mod_Ocorrencia Oc1 = new Mod_Ocorrencia (Stb_alunoA,dataA1,"Matou aula");
		Mod_Ocorrencia Oc2 = new Mod_Ocorrencia (Stb_alunoB,dataA1,"Pulou o muro");
				
		CtrlOcorrencia.inserirOcorrencia(Oc1);
		CtrlOcorrencia.inserirOcorrencia(Oc2);
		
		//1. SolicitOcorrencia()
		//2. ListaOcorrencia()
		//3. listaOcorrencia[] = obtemOcorrencia()
		//4. ConsultaOcorrencia()
		System.out.println(CtrlOcorrencia.obtemOcorrencia(Stb_alunoA));
			    	
		
				

	}

}
