import java.util.ArrayList;
import java.util.Date;

public class CtlOcorrencia {
	
	private ArrayList<Ocorrencia> Stb_BDOcorrencia = new ArrayList<Ocorrencia>();
	
	//Construtores
	public CtlOcorrencia(){
		super();
	}
	
	//metodos
	//Salvar ocorrencia
	public void inserirOcorrencia(Ocorrencia Oc){
		
		Oc.setID_ocorrencia(Stb_BDOcorrencia.size()+1);
		Stb_BDOcorrencia.add(Oc);
		
	}
	
	//Obtem ocorrencias por Aluno
	public CtlOcorrencia obtemOcorrencia(Aluno a){
		
		CtlOcorrencia OcorAluno = new CtlOcorrencia();
		
		for(int i=0;i<Stb_BDOcorrencia.size();i++){
			if(Stb_BDOcorrencia.get(i).getAluno().getRA()==a.getRA()){
				OcorAluno.Stb_BDOcorrencia.add(Stb_BDOcorrencia.get(i));
			}
		}
		
		return OcorAluno;
	}	
	
	//Obtem ocorrencia por Turma
	public CtlOcorrencia obtemOcorrencia (Turma t){
		
		CtlOcorrencia OcorTurma = new CtlOcorrencia();
		for(int i=0;i<Stb_BDOcorrencia.size();i++){
			if(Stb_BDOcorrencia.get(i).getAluno().getTurma().getNomeTurma()==t.getNomeTurma()){
				OcorTurma.Stb_BDOcorrencia.add(Stb_BDOcorrencia.get(i));
				
			}
		}
		
		return OcorTurma;
		
	}
	
	//Editando uma ocorrencia
	public void editarOcorrencia(int IDOc,Aluno alu,Date data,String desc){
		
		for(int i=0;i<Stb_BDOcorrencia.size();i++){
			
			if(Stb_BDOcorrencia.get(i).getID_ocorrencia() == IDOc){
				//alterando o aluno
				Stb_BDOcorrencia.get(i).setAluno(alu);
				Stb_BDOcorrencia.get(i).setData_ocorrencia(data);
				Stb_BDOcorrencia.get(i).setDesc_ocorrencia(desc);
			}
		}
		
	}
	//Excluindo uma ocorrencia da lista de Ocorrencia
	public void excluirOcorrencia(int IDOc){
		for(int i=0;i<Stb_BDOcorrencia.size();i++){
			
			if(Stb_BDOcorrencia.get(i).getID_ocorrencia() == IDOc){
				//excluindo o aluno
				Stb_BDOcorrencia.remove(i);
			}
		}
	}
	
		
	//toString 
	public String toString(){
		String res = "Lista de Ocorrencias";
		
		for(int i=0;i<Stb_BDOcorrencia.size();i++){
			res+=Stb_BDOcorrencia.get(i).toString();
		}
		
		return res;
	}
}
