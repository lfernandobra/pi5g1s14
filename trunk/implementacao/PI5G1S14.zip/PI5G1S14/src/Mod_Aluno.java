
public class Mod_Aluno {
	
	private String RA;
	private String Nome;
	private Mod_Turma turma;
	
	
	//Getters and Setters
	
	public String getRA() {
		return RA;
	}
	public void setRA(String rA) {
		RA = rA;
	}
	public String getNome() {
		return Nome;
	}
	public void setNome(String nome) {
		Nome = nome;
	}
	public Mod_Turma getTurma() {
		return turma;
	}
	public void setTurma(Mod_Turma turma) {
		this.turma = turma;
	}
	
	//Construtores
	
	public Mod_Aluno(){
		super();
	}
	
	public Mod_Aluno(String RA,String Nome,Mod_Turma turma){
		super();
		this.RA = RA;
		this.Nome = Nome;
		this.turma = turma;
	}
	
	//toString
	public String toString(){
		return "\nRA : "+RA+
				"\nNome : "+Nome+
				"\nTurma : "+turma;
	}
	
	
	
}
