import java.util.ArrayList;
import java.util.Date;

public class Mod_CtrlOcorrencia {
	
	private ArrayList<Mod_Ocorrencia> Stb_ocorrencias = new ArrayList<Mod_Ocorrencia>();
	
	//Construtores
	public Mod_CtrlOcorrencia(){
		super();
	}
	
	//metodos
	//Salvar ocorrencia
	public void inserirOcorrencia(Mod_Ocorrencia Oc){
		Stb_ocorrencias.add(Oc);
	}
	
	//Obtem ocorrencias por Aluno
	public Mod_CtrlOcorrencia obtemOcorrencia(Mod_Aluno a){
		
		Mod_CtrlOcorrencia OcorAluno = new Mod_CtrlOcorrencia();
		for(int i=0;i<Stb_ocorrencias.size();i++){
			if(Stb_ocorrencias.get(i).getAluno().getRA()==a.getRA()){
				OcorAluno.Stb_ocorrencias.add(Stb_ocorrencias.get(i));
			}
		}
		
		return OcorAluno;
	}
	
	//Obtem ocorrencia por Turma
	public Mod_CtrlOcorrencia obtemOcorrencia (Mod_Turma t){
		
		Mod_CtrlOcorrencia OcorTurma = new Mod_CtrlOcorrencia();
		for(int i=0;i<Stb_ocorrencias.size();i++){
			if(Stb_ocorrencias.get(i).getAluno().getTurma().getNomeTurma()==t.getNomeTurma()){
				OcorTurma.Stb_ocorrencias.add(Stb_ocorrencias.get(i));
				
			}
		}
		
		return OcorTurma;
		
	}
	
	//Editando uma ocorrencia
	public void editarOcorrencia(int IDOc,Mod_Aluno alu,Date data,String desc){
		
		for(int i=0;i<Stb_ocorrencias.size();i++){
			
			if(Stb_ocorrencias.get(i).getID_ocorrencia() == IDOc){
				//alterando o aluno
				Stb_ocorrencias.get(i).setAluno(alu);
				Stb_ocorrencias.get(i).setData_ocorrencia(data);
				Stb_ocorrencias.get(i).setDesc_ocorrencia(desc);
			}
		}
		
	}
	//Excluindo uma ocorrencia da lista de Ocorrencia
	public void excluirOcorrencia(int IDOc){
		for(int i=0;i<Stb_ocorrencias.size();i++){
			
			if(Stb_ocorrencias.get(i).getID_ocorrencia() == IDOc){
				//excluindo o aluno
				Stb_ocorrencias.remove(i);
			}
		}
	}
	
		
	//toString 
	public String toString(){
		String res = "Lista de Ocorrencias";
		
		for(int i=0;i<Stb_ocorrencias.size();i++){
			res+=Stb_ocorrencias.get(i).toString();
		}
		
		return res;
	}
}
