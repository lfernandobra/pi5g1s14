import java.util.ArrayList;
import java.util.Date;

public class Mod_listaOcorrencia {
	
	private ArrayList<Mod_Ocorrencia> ocorrencias = new ArrayList<Mod_Ocorrencia>();
	
	//Construtores
	public Mod_listaOcorrencia(){
		super();
	}
	
	//metodos
	//Salvar ocorrencia
	public void inserirOcorrencia(Mod_Ocorrencia Oc){
		ocorrencias.add(Oc);
	}
	
	//Obtem ocorrencias por Aluno
	public Mod_listaOcorrencia obtemOcorrencia(Mod_Aluno a){
		
		Mod_listaOcorrencia OcorAluno = new Mod_listaOcorrencia();
		for(int i=0;i<ocorrencias.size();i++){
			if(ocorrencias.get(i).getAluno().getRA()==a.getRA()){
				OcorAluno.ocorrencias.add(ocorrencias.get(i));
			}
		}
		
		return OcorAluno;
	}
	
	//Obtem ocorrencia por Turma
	public Mod_listaOcorrencia obtemOcorrencia (Mod_Turma t){
		
		Mod_listaOcorrencia OcorTurma = new Mod_listaOcorrencia();
		for(int i=0;i<ocorrencias.size();i++){
			if(ocorrencias.get(i).getAluno().getTurma().getNomeTurma()==t.getNomeTurma()){
				OcorTurma.ocorrencias.add(ocorrencias.get(i));
				
			}
		}
		
		return OcorTurma;
		
	}
	
	//Editando uma ocorrencia
	public void editarOcorrencia(int IDOc,Mod_Aluno alu,Date data,String desc){
		
		for(int i=0;i<ocorrencias.size();i++){
			
			if(ocorrencias.get(i).getID_ocorrencia() == IDOc){
				//alterando o aluno
				ocorrencias.get(i).setAluno(alu);
				ocorrencias.get(i).setData_ocorrencia(data);
				ocorrencias.get(i).setDesc_ocorrencia(desc);
			}
		}
		
	}
	//Excluindo uma ocorrencia da lista de Ocorrencia
	public void excluirOcorrencia(int IDOc){
		for(int i=0;i<ocorrencias.size();i++){
			
			if(ocorrencias.get(i).getID_ocorrencia() == IDOc){
				//excluindo o aluno
				ocorrencias.remove(i);
			}
		}
	}
	
		
	//toString 
	public String toString(){
		String res = "Lista de Ocorrencias";
		
		for(int i=0;i<ocorrencias.size();i++){
			res+=ocorrencias.get(i).toString();
		}
		
		return res;
	}
}
