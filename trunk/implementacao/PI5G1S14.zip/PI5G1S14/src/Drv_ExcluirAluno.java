import javax.swing.JOptionPane;


public class Drv_ExcluirAluno {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
				
		// instanciando alunos com seus respectivos parametros (RA,Nome,Turma)
		Mod_Aluno Stb_alunoA = new Mod_Aluno("1","Ana",Stb_turmaA);
		Mod_Aluno Stb_alunoB = new Mod_Aluno("2","Luis Fernando",Stb_turmaB);
		Mod_Aluno Stb_alunoC = new Mod_Aluno("3","Luiza Helena",Stb_turmaA);
		Mod_Aluno Stb_alunoD = new Mod_Aluno("4","Waldinei",Stb_turmaB);
		
		// instanciado a lista de alunos
		Mod_listaAluno Stb_listaAlunoADS = new Mod_listaAluno();
				
				
		// inserindo alunos a lista de alunos
		Stb_listaAlunoADS.inserirAluno(Stb_alunoA);
		Stb_listaAlunoADS.inserirAluno(Stb_alunoB);
		Stb_listaAlunoADS.inserirAluno(Stb_alunoC);
		Stb_listaAlunoADS.inserirAluno(Stb_alunoD);
		
		// exibindo a lista de alunos
		JOptionPane.showMessageDialog(null, Stb_listaAlunoADS);
		
		// excluindo alunos recebendo como parametro o RA
		
		Stb_listaAlunoADS.excluirAluno("1");
		
		JOptionPane.showMessageDialog(null, Stb_listaAlunoADS);
		
		Stb_listaAlunoADS.excluirAluno("2");
		
		JOptionPane.showMessageDialog(null, Stb_listaAlunoADS);
		
		Stb_listaAlunoADS.excluirAluno("3");
		
		JOptionPane.showMessageDialog(null, Stb_listaAlunoADS);
		
		Stb_listaAlunoADS.excluirAluno("4");
		
		JOptionPane.showMessageDialog(null, Stb_listaAlunoADS);

	}

}
