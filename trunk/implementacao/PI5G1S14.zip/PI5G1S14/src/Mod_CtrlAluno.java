import java.util.ArrayList;

public class Mod_CtrlAluno {
	
	private ArrayList<Mod_Aluno> Stb_alunos = new ArrayList<Mod_Aluno>();
	
	//Construtores
	
	public Mod_CtrlAluno(){
		super();
	}
		
	//metodos
	
	//salvar aluno a lista de alunos
	public void inserirAluno(Mod_Aluno a){
		Stb_alunos.add(a);
	}
	
	//obtem aluno da lista
	public Mod_Aluno obtemAluno(String RA){
		Mod_Aluno aluno = new Mod_Aluno();
		for (int i = 0;i<Stb_alunos.size();i++){
			if(Stb_alunos.get(i).getRA()== RA){
				aluno = Stb_alunos.get(i);
			}
		}
		return aluno;
		
	}
	
	//Editando um aluno 
	public void editarAluno(String RA,String nome,Mod_Turma turma){
			
		for(int i=0;i<Stb_alunos.size();i++){
				
			if(Stb_alunos.get(i).getRA() == RA){
			//alterando o aluno
			  Stb_alunos.get(i).setNome(nome);
			  Stb_alunos.get(i).setTurma(turma);
			}
		}
			
	}
	
	
	//Excluindo um aluno da lista de alunos
		public void excluirAluno(String RA){
			for(int i=0;i<Stb_alunos.size();i++){
				
				if(Stb_alunos.get(i).getRA() == RA){
					//excluindo o aluno
					Stb_alunos.remove(i);
				}
			}
		}
	
	
	//toString
	public String toString(){
		String res = "Lista de alunos";
		
		for(int i=0;i<Stb_alunos.size();i++){
			res+=Stb_alunos.get(i).toString();
		}		
		return res;
	}
	
	
	
	
}
