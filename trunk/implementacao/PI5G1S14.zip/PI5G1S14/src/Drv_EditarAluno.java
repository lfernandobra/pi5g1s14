import javax.swing.JOptionPane;


public class Drv_EditarAluno {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//instanciando objetos da classe Turma
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
		
		// instanciando alunos com seus respectivos parametros (RA,Nome,Turma)
		Mod_Aluno Stb_alunoA = new Mod_Aluno("1","Ana",Stb_turmaA);
		//Aluno Stb_alunoB = new Aluno("2","Luis Fernando",Stb_turmaB);
		//Aluno Stb_alunoC = new Aluno("3","Luiza Helena",Stb_turmaA);
		//Aluno Stb_alunoD = new Aluno("4","Waldinei",Stb_turmaB);
		
		// instanciado um objeto controle aluno
		Mod_CtrlAluno CtrlAluno = new Mod_CtrlAluno();
		
		// inserindo alunos a lista de alunos
		CtrlAluno.inserirAluno(Stb_alunoA);
		
		// exibindo a lista de alunos
		JOptionPane.showMessageDialog(null,CtrlAluno);
		
		// ap�s edi��o
		
		CtrlAluno.editarAluno("1", "Luis Fernando", Stb_turmaB);
		
		JOptionPane.showMessageDialog(null,CtrlAluno);
		
		
	}

}
