import java.util.ArrayList;

public class Mod_listaAluno {
	
	private ArrayList<Mod_Aluno> alunos = new ArrayList<Mod_Aluno>();
	
	//Construtores
	
	public Mod_listaAluno(){
		super();
	}
		
	//metodos
	
	//salvar aluno a turma
	public void inserirAluno(Mod_Aluno a){
		alunos.add(a);
	}
	
	//obtem aluno da turma
	public Mod_Aluno obtemAluno(String RA){
		Mod_Aluno aluno = new Mod_Aluno();
		for (int i = 0;i>alunos.size();i++){
			if(alunos.get(i).getRA()== RA){
				aluno = alunos.get(i);
			}
		}
		return aluno;
		
	}
	
	//Editando um aluno 
	public void editarAluno(String RA,String nome,Mod_Turma turma){
			
		for(int i=0;i<alunos.size();i++){
				
			if(alunos.get(i).getRA() == RA){
			//alterando o aluno
			  alunos.get(i).setNome(nome);
			  alunos.get(i).setTurma(turma);
			}
		}
			
	}
	
	
	//Excluindo um aluno da lista de alunos
		public void excluirAluno(String RA){
			for(int i=0;i<alunos.size();i++){
				
				if(alunos.get(i).getRA() == RA){
					//excluindo o aluno
					alunos.remove(i);
				}
			}
		}
	
	
	//toString
	public String toString(){
		String res = "Lista de alunos";
		
		for(int i=0;i<alunos.size();i++){
			res+=alunos.get(i).toString();
		}		
		return res;
	}
	
	
	
	
}
