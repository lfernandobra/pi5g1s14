
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JOptionPane;



public class Drv_InserirOcorrencia {

			
	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
		
		// instanciando alunos com seus respectivos parametros (RA,Nome,Turma)
		Mod_Aluno Stb_alunoA = new Mod_Aluno("1","Ana",Stb_turmaA);
		Mod_Aluno Stb_alunoB = new Mod_Aluno("2","Luis Fernando",Stb_turmaB);
		Mod_Aluno Stb_alunoC = new Mod_Aluno("3","Luiza Helena",Stb_turmaA);
		Mod_Aluno Stb_alunoD = new Mod_Aluno("4","Waldinei",Stb_turmaB);
		
		// instanciado a lista de alunos
		Mod_listaAluno Stb_listaAlunoADS = new Mod_listaAluno();
		
		
		// inserindo alunos a lista de alunos
		Stb_listaAlunoADS.inserirAluno(Stb_alunoA);
		Stb_listaAlunoADS.inserirAluno(Stb_alunoB);
		Stb_listaAlunoADS.inserirAluno(Stb_alunoC);
		Stb_listaAlunoADS.inserirAluno(Stb_alunoD);
		
		//Formatador para o atributo tipo date
		SimpleDateFormat formatador = new SimpleDateFormat("dd/MM/yyyy");
		
		Date dataA1 = formatador.parse("24/04/2014");
		Date dataA2 = formatador.parse("23/03/2014");
	    	
		
		
		// instanciando a lista de Ocorrencias
		Mod_listaOcorrencia Stb_listaOcorrenciaADS = new Mod_listaOcorrencia();
		
		// exibindo a lista de ocorrencias
		JOptionPane.showMessageDialog(null,Stb_listaOcorrenciaADS);
		
		// instanciando ocorrencias para os respectivos alunos
		
		Mod_Ocorrencia A1 = new Mod_Ocorrencia(1,Stb_alunoA,dataA1,"Desrespeito ao Professor em sala de aula");
		Mod_Ocorrencia A2 = new Mod_Ocorrencia(2,Stb_alunoB,dataA2,"Saiu antes do termino da aula");
		
		// adicionando ocorrencias a lista
		Stb_listaOcorrenciaADS.inserirOcorrencia(A1);
		
		JOptionPane.showMessageDialog(null,Stb_listaOcorrenciaADS);
		
		Stb_listaOcorrenciaADS.inserirOcorrencia(A2);
		
		JOptionPane.showMessageDialog(null,Stb_listaOcorrenciaADS);
		
		

	}

}
