import javax.swing.JOptionPane;


public class Drv_ConsultarTurma {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
		Mod_Turma Stb_turmaC = new Mod_Turma("C","2012");
		Mod_Turma Stb_turmaD = new Mod_Turma("D","2011");
		
		//instanciado a um objeto da classe controle de alunos
		Mod_CtrlTurma CtrlTurma = new Mod_CtrlTurma();
		
		// inserindo turmas a lista de turma
		
		CtrlTurma.inserirTurma(Stb_turmaA);
		CtrlTurma.inserirTurma(Stb_turmaB);
		CtrlTurma.inserirTurma(Stb_turmaC);
		CtrlTurma.inserirTurma(Stb_turmaD);
		
		
		// consultando as turmas atrav�s do nome
		JOptionPane.showMessageDialog(null,CtrlTurma.obtemTurma("D"));
		JOptionPane.showMessageDialog(null,CtrlTurma.obtemTurma("C"));
		JOptionPane.showMessageDialog(null,CtrlTurma.obtemTurma("A"));
		JOptionPane.showMessageDialog(null,CtrlTurma.obtemTurma("B"));
				
	}

}
