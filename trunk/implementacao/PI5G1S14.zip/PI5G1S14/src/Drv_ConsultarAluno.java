
import javax.swing.JOptionPane;


public class Drv_ConsultarAluno {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
				
		//instanciado objetos da classe Aluno
		Mod_Aluno Stb_alunoA = new Mod_Aluno("1","Ana",Stb_turmaA);
		Mod_Aluno Stb_alunoB = new Mod_Aluno("2","Luis Fernando",Stb_turmaB);
		Mod_Aluno Stb_alunoC = new Mod_Aluno("3","Luiza Helena",Stb_turmaA);
		Mod_Aluno Stb_alunoD = new Mod_Aluno("4","Waldinei",Stb_turmaB);
				
				
		//instanciado a um objeto da classe controle de alunos
		Mod_CtrlAluno CtrlAluno = new Mod_CtrlAluno();
				
		// inserindo alunos a lista de alunos
				
		CtrlAluno.inserirAluno(Stb_alunoA);
		
		CtrlAluno.inserirAluno(Stb_alunoB);
		
		CtrlAluno.inserirAluno(Stb_alunoC);
		
		CtrlAluno.inserirAluno(Stb_alunoD);
		
		JOptionPane.showMessageDialog(null,CtrlAluno.obtemAluno("1"));
							
		JOptionPane.showMessageDialog(null,CtrlAluno.obtemAluno("3"));
						
		JOptionPane.showMessageDialog(null,CtrlAluno.obtemAluno("2"));
				
		JOptionPane.showMessageDialog(null,CtrlAluno.obtemAluno("4"));
				

	}

}
