import javax.swing.JOptionPane;


public class Drv_InserirAluno {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//instanciando objetos da classe Turma
		Mod_Turma Stb_turmaA = new Mod_Turma("A","2014");
		Mod_Turma Stb_turmaB = new Mod_Turma("B","2013");
		
		//instanciado objetos da classe Aluno
		Mod_Aluno Stb_alunoA = new Mod_Aluno("1","Ana",Stb_turmaA);
		Mod_Aluno Stb_alunoB = new Mod_Aluno("2","Luis Fernando",Stb_turmaB);
		Mod_Aluno Stb_alunoC = new Mod_Aluno("3","Luiza Helena",Stb_turmaA);
		Mod_Aluno Stb_alunoD = new Mod_Aluno("4","Waldinei",Stb_turmaB);
		
		
		//instanciado a um objeto da classe controle de alunos
		Mod_CtrlAluno CtrlAluno = new Mod_CtrlAluno();
		
		// inserindo alunos a lista de alunos
		
		CtrlAluno.inserirAluno(Stb_alunoA);
		
		JOptionPane.showMessageDialog(null,CtrlAluno);
		
		CtrlAluno.inserirAluno(Stb_alunoB);
		
		JOptionPane.showMessageDialog(null,CtrlAluno);
		
		CtrlAluno.inserirAluno(Stb_alunoC);
		
		JOptionPane.showMessageDialog(null,CtrlAluno);
		
		CtrlAluno.inserirAluno(Stb_alunoD);
		
		JOptionPane.showMessageDialog(null,CtrlAluno);
		
		

	}

}
